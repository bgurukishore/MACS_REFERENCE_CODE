USE $(SQLCMDDBNAME)
GO

DELETE FROM [$(SQLCMDDBNAME)].[dbo].[ESB_CORE_NOTIFICATION];

INSERT INTO [$(SQLCMDDBNAME)].[dbo].[ESB_CORE_NOTIFICATION] ([ESBN_NOTIFY_CODE],[ESBN_DECRIPTION],[ESBN_NOTIFICATION_TYPE],[ESBN_EMAIL_TO],[ESBN_EMAIL_CC])
  VALUES
  (40, 'ACE Data Configuration Errors', 'SEND_EMAIL', 'local-part@domain', NULL),
  (50, 'Validation Errors', 'SEND_EMAIL', 'local-part@domain', NULL),
  (60, 'Processing Errors', 'SEND_EMAIL', 'local-part@domain', NULL);