USE [$(SQLCMDDBNAME)]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DEPLOY_LOG]') AND type in (N'U'))
	CREATE TABLE [dbo].[DEPLOY_LOG](
		[INTEGRATION_NODE] [varchar](250) NULL,
		[INTEGRATION_SERVER] [varchar](250) NULL,
		[OBJECT_NAME] [varchar](250) NULL,
		[OBJECT_VERS] [varchar](50) NULL,
		[BUILD_TIME] [datetimeoffset](7) NULL,
		[BUILT_BY] [varchar](250) NULL,
		[DEPLOY_TIME] [datetimeoffset](7) NULL,
		[DEPLOYED_BY] [varchar](250) NULL
	) ON [PRIMARY]
	GO


