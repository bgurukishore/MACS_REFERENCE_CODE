USE [$(SQLCMDDBNAME)]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[REF_DATA]') AND type in (N'U'))
	CREATE TABLE [dbo].[REF_DATA](
		[REF_DOMAIN] [varchar](50) NOT NULL,
		[REF_KEY] [nvarchar](250) NOT NULL,
		[REF_VALUE] [nvarchar](500) NOT NULL
	) ON [PRIMARY]
	GO
	

