USE [$(SQLCMDDBNAME)]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ROUTING_DATA]') AND type in (N'U'))
	CREATE TABLE [dbo].[ROUTING_DATA](
		[MSGFLOW] [nvarchar](50) NOT NULL,
		[FILTER] [nvarchar](20) NULL,
		[ESQL_MODULE] [nvarchar](100) NULL,
		[SEQUENCE] [smallint] NOT NULL,
		[ROUTING_TABLE] [nvarchar](100) NULL,
		[TARGET_URI] [nvarchar](100) NULL,
		[REPLY_URI] [nvarchar](100) NULL
	) ON [PRIMARY]
	GO
	
	
