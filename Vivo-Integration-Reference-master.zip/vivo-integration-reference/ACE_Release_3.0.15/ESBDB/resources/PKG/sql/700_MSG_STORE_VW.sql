USE [$(SQLCMDDBNAME)]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE OR ALTER VIEW [dbo].[MSG_STORE_VW] AS
SELECT CONVERT([varchar](32), [MSG_ID], 2) AS [MSG_ID]
      ,[SOURCE_QUEUE]
      ,[MSG_TMS]
      ,[SOURCE_SYSTEM]
      ,[TARGET_SYSTEM]
      ,[APPL_NAME]
      ,[FLOW_NAME]
      ,CONVERT([varchar](128), [MSG_HASH], 2) AS [MSG_HASH]
      ,[MSG_DATA]
      ,CONVERT([nvarchar](max), [MSG_RAW], 2) AS [MSG_RAW]
  FROM [dbo].[MSG_STORE]

GO


