USE [$(SQLCMDDBNAME)]
GO

DELETE FROM [dbo].[REF_DATA] WHERE [REF_DOMAIN] = 'SON_TYPE';

INSERT INTO dbo.REF_DATA (REF_DOMAIN,REF_KEY,REF_VALUE) VALUES 
('SON_TYPE','MAMAINT','Major Maintain'),
('SON_TYPE','MASUST','Major Sustain'),
('SON_TYPE','MIMAINT','Minor Maintain'),
('SON_TYPE','MISUST','Minor Sustain'),
('SON_TYPE','MACHG','Major Change'),
('SON_TYPE','MICHG','Minor Change');
