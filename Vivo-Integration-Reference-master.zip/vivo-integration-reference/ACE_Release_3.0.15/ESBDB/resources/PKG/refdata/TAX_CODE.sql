USE [$(SQLCMDDBNAME)]
GO

DELETE FROM [dbo].[REF_DATA] WHERE [REF_DOMAIN] = 'TAX_CODE';

INSERT INTO [dbo].[REF_DATA] ([REF_DOMAIN],[REF_KEY],[REF_VALUE]) VALUES
('TAX_CODE','C0','C0 - Contracted Out Zero Rate (COSVAT)'),
('TAX_CODE','C1','C1 - Contracted Out Standard Rate (COSVAT)'),
('TAX_CODE','C3','C3 - Contracted Out Reduced Rate (COSVAT)'),
('TAX_CODE','E0','E0 - EU Taxable Zero Rate'),
('TAX_CODE','E1','E1 - EU Taxable Standard Rate'),
('TAX_CODE','E3','E3 - EU Taxable Reduced Rate'),
('TAX_CODE','F0','F0 - Taxable Zero Rate (Goods and Services)'),
('TAX_CODE','F1','F1 - Taxable Standard Rate (Goods and Services)'),
('TAX_CODE','F3','F3 - Taxable Reduced Rate (Goods and Services)'),
('TAX_CODE','J1','J1 - EU Taxable Standard Rate (Self-Assessment COSVAT)'),
('TAX_CODE','K1','K1 - Non-EU Taxable Standard Rate (Self-Assessment COSVAT)'),
('TAX_CODE','N0','N0 - Outside the Scope, Exempt or Irrecoverable'),
('TAX_CODE','P0','P0 - Outside the Scope or Exempt'),
('TAX_CODE','R0','R0 - Taxable Zero Rate (Resale and Business)'),
('TAX_CODE','R1','R1 - Taxable Standard Rate (Resale and Business)'),
('TAX_CODE','R3','R3 - Taxable Reduced Rate (Resale and Business)'),
('TAX_CODE','S0','S0 - Zero Rate'),
('TAX_CODE','S1','S1 - Standard Rate'),
('TAX_CODE','S3','S3 - Reduced Rate'),
('TAX_CODE','T0','T0 - Zero Rate (Expenditure Code R)'),
('TAX_CODE','T1','T1 - Standard Rate (Expenditure Code R)'),
('TAX_CODE','T3','T3 - Reduced Rate (Expenditure Code R)'),
('TAX_CODE','U0','U0 - Non-EU Taxable Zero Rate'),
('TAX_CODE','U1','U1 - Non- EU Taxable Standard Rate'),
('TAX_CODE','U3','U3 - Non-EU Taxable Reduced Rate'),
('TAX_CODE','X0','X0 - Exempt Non VAT Bearing'),
('TAX_CODE','Z0','Z0 - Outside Scope of UK VAT');