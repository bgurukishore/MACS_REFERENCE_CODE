USE [$(SQLCMDDBNAME)]
GO

DELETE FROM [dbo].[REF_DATA] WHERE [REF_DOMAIN] = 'PRIORITY_NAME';

INSERT INTO dbo.REF_DATA (REF_DOMAIN,REF_KEY,REF_VALUE) VALUES 
('PRIORITY_NAME','IMMINENT','1 - Critical failure is imminent and code violations'),
('PRIORITY_NAME','1-2YEARS','2 - Will become critical in 1-2 years'),
('PRIORITY_NAME','3-4YEARS','3 - Will become critical in 3-4 years'),
('PRIORITY_NAME','WISHLIST','4 - Wish List (nice to have)'),
('PRIORITY_NAME','GF','5 - Grandfather code issues and ADA'),
('PRIORITY_NAME','NEW','6 - New Construction'),
('PRIORITY_NAME','CRITICAL','Critical'),
('PRIORITY_NAME','EMERGENCY','Emergency'),
('PRIORITY_NAME','ROUTINE','Routine'),
('PRIORITY_NAME','URGENT','Urgent'),
('PRIORITY_NAME','WANDW','Wind and Weatherproof');
