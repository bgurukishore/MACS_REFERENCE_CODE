package com.dio.utils;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;

public class EclipseWorkspace {
	private File workspace = null;
	private Map<String, EclipseProject> eclipseProjects = new LinkedHashMap<String, EclipseProject>();

	public EclipseWorkspace(File workspace) {
		super();
		this.workspace = workspace;
		try {
			readProjectFiles();
		} catch (Exception e) {
			throw new BuildException(e);
		}
	}

	private void readProjectFiles() throws IOException {
		File projectFile = null, locationFile = null;
		eclipseProjects.clear();
		DirectoryScanner ds = new DirectoryScanner();
		ds.setIncludes(new String[] {
				".metadata\\.plugins\\org.eclipse.core.resources\\.projects\\*\\.location",
				"*\\.project" });
		ds.setExcludes(new String[] { ".metadata\\.plugins\\org.eclipse.core.resources\\.projects\\.*\\.location" });
		ds.setBasedir(new File(workspace, ""));
		ds.setCaseSensitive(false);
		ds.scan();
		for (String filename : ds.getIncludedFiles()) {
			if (".project".equalsIgnoreCase(FilenameUtils.getName(filename))) {
				projectFile = new File(workspace, filename);
			} else if (".location".equalsIgnoreCase(FilenameUtils
					.getName(filename))) {
				locationFile = new File(ds.getBasedir(), filename);
				String locationContent = FileUtils.readFileToString(
						locationFile, Charset.defaultCharset());
				String projectDir = RegExpHelper.find(locationContent,
						"URI//file:/([\\w/:_]+)", 1);
				projectFile = new File(projectDir, ".project");
			}
			EclipseProject eclipseProject = new EclipseProject(projectFile);
			eclipseProjects.put(eclipseProject.getName(), eclipseProject);
		}
		for (EclipseProject eclipseProject : eclipseProjects.values()) {
			Set<EclipseProject> dependencies = new TreeSet<EclipseProject>();
			identifyDependencies(eclipseProject, dependencies);
			eclipseProject.setDependencies(dependencies);
		}
	}

	private void identifyDependencies(EclipseProject eclipseProject,
			Set<EclipseProject> dependencies) {
		if (eclipseProject.getDependencies().isEmpty()) {
			for (String referencedProjectName : eclipseProject
					.getReferencedProjects()) {
				EclipseProject referencedProject = eclipseProjects
						.get(referencedProjectName);
				if (referencedProject == null) {
					continue;
				}
				dependencies.add(referencedProject);
				identifyDependencies(referencedProject, dependencies);
			}
		}
	}

	public File getWorkspace() {
		return workspace;
	}

	public Map<String, EclipseProject> getEclipseProjects() {
		Map<String, EclipseProject> copyOfEclipseProjects = new LinkedHashMap<String, EclipseProject>();
		for (Map.Entry<String, EclipseProject> entry : eclipseProjects
				.entrySet()) {
			copyOfEclipseProjects.put(entry.getKey(), entry.getValue());
		}
		return copyOfEclipseProjects;
	}

}
