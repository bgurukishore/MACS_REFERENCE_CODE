package com.dio.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

public class RegExpHelper {

	public static Boolean matches(String value, String pattern) {
		if (StringUtils.isBlank(value)) {
			return false;
		}
		if (StringUtils.isBlank(pattern)) {
			return false;
		}
		Pattern p = Pattern.compile(pattern);
		Matcher matcher = p.matcher(value);
		return matcher.matches();
	}

	public static String find(String value, String pattern, int group) {
		if (StringUtils.isBlank(value)) {
			return null;
		}
		if (StringUtils.isBlank(pattern)) {
			return null;
		}
		Pattern p = Pattern.compile(pattern);
		Matcher matcher = p.matcher(value);
		if (matcher.find()) {
			return matcher.group(group);
		}
		return null;
	}
}
