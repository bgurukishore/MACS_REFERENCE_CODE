package com.dio.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.tools.ant.BuildException;
import org.xml.sax.SAXException;

public class EclipseProject implements Comparable<EclipseProject> {
	private File projectFile = null;
	private String name = null;
	private Set<String> natures = new TreeSet<String>();
	private Set<String> referencedProjects = new TreeSet<String>();
	private Set<EclipseProject> dependencies = new TreeSet<EclipseProject>();

	public EclipseProject(File projectFile) throws BuildException {
		super();
		try {
			this.projectFile = projectFile.getCanonicalFile();
		} catch (IOException e1) {
			this.projectFile = projectFile.getAbsoluteFile();
		}
		try {
			readProjectFile();
		} catch (Exception e) {
			throw new BuildException(e);
		}
	}

	private void readProjectFile() throws FileNotFoundException, IOException,
			SAXException, ParserConfigurationException,
			XPathExpressionException {
		XmlHelper xmlHelper = new XmlHelper(projectFile);
		name = xmlHelper
				.getNodeValue("//*[local-name()='projectDescription']/*[local-name()='name']/text()");
		referencedProjects.clear();
		referencedProjects
				.addAll(xmlHelper
						.getNodeValues("//*[local-name()='projectDescription']/*[local-name()='projects']/*[local-name()='project']/text()"));
		natures.clear();
		natures.addAll(xmlHelper
				.getNodeValues("//*[local-name()='projectDescription']/*[local-name()='natures']/*[local-name()='nature']/text()"));
	}

	public String getName() {
		return name;
	}

	public File getProjectDir() {
		return projectFile.getParentFile();
	}

	public List<String> getReferencedProjects() {
		List<String> copyOf = new ArrayList<String>();
		copyOf.addAll(referencedProjects);
		return copyOf;
	}

	public List<String> getNatures() {
		List<String> copyOf = new ArrayList<String>();
		copyOf.addAll(natures);
		return copyOf;
	}

	public List<EclipseProject> getDependencies() {
		List<EclipseProject> copyOf = new ArrayList<EclipseProject>();
		copyOf.addAll(dependencies);
		return copyOf;
	}

	public void setDependencies(Set<EclipseProject> dependencies) {
		this.dependencies.clear();
		this.dependencies.addAll(dependencies);
	}

	public boolean isACEProject() {
		return natures
				.contains("com.ibm.etools.msgbroker.tooling.messageBrokerProjectNature");
	}

	public boolean isACEApplication() {
		return isACEProject()
				&& natures
						.contains("com.ibm.etools.msgbroker.tooling.applicationNature");
	}

	public boolean isACESharedLibrary() {
		return isACEProject()
				&& natures
						.contains("com.ibm.etools.msgbroker.tooling.libraryNature")
				&& natures
						.contains("com.ibm.etools.msgbroker.tooling.sharedLibraryNature");
	}

	public boolean isACEStaticLibrary() {
		return isACEProject()
				&& natures
						.contains("com.ibm.etools.msgbroker.tooling.libraryNature")
				&& !isACESharedLibrary();
	}

	public boolean isACELinkedJavaProject() {
		return natures.contains("org.eclipse.jdt.core.javanature")
				&& natures.contains("com.ibm.etools.mft.jcn.jcnnature")
				&& natures.contains("com.ibm.etools.mft.bar.ext.barnature");
	}

	public boolean isACEPolicyProject() {
		return natures.contains("com.ibm.etools.mft.policy.ui.Nature");
	}

	@Override
	public String toString() {
		return "EclipseProject [projectFile=" + projectFile + ", name=" + name
				+ ", referencedProjects=" + referencedProjects
				+ ", dependencies=" + dependencies + "]";
	}

	@Override
	public int compareTo(EclipseProject otherEclipseProject) {
		return getName().compareToIgnoreCase(otherEclipseProject.getName());
	}

	public File getResourcesDir() {
		return new File(getProjectDir(), "resources");
	}

	public File getPackageDir() {
		return new File(getResourcesDir(), "PKG");
	}

	public File getMqscDir() {
		return new File(getPackageDir(), "mqsc");
	}

	public File getSqlDir() {
		return new File(getPackageDir(), "sql");
	}

	public File getOverridesDir() {
		return new File(getPackageDir(), "overrides");
	}

	public File getBuildDir() {
		return new File(this.getProjectDir(), "build");
	}

	public File getDistDir() {
		return new File(this.getProjectDir(), "dist");
	}
}
