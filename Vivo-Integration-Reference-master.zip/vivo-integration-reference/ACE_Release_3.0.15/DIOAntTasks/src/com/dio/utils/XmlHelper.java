package com.dio.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XmlHelper {
	private final XPathFactory xPathfactory = XPathFactory.newInstance();
	private final XPath xpath = xPathfactory.newXPath();
	private File xmlFile = null;
	private Document document = null;

	public XmlHelper(File xmlFile) throws FileNotFoundException, IOException,
			SAXException, ParserConfigurationException {
		super();
		this.xmlFile = xmlFile;

		try (InputStream in = new FileInputStream(this.xmlFile)) {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
					.newInstance();
			documentBuilderFactory.setNamespaceAware(true);
			this.document = documentBuilderFactory.newDocumentBuilder().parse(
					in);
		}
	}

	public String getNodeValue(String xpathStr) throws XPathExpressionException {
		XPathExpression expr = xpath.compile(xpathStr);
		return expr.evaluate(this.document);
	}

	public List<String> getNodeValues(String xpathStr)
			throws XPathExpressionException {
		List<String> values = new ArrayList<String>();
		NodeList nodes = getNodes(xpathStr);
		for (int i = 0; i < nodes.getLength(); i++) {
			values.add(nodes.item(i).getNodeValue());
		}
		return values;
	}

	public NodeList getNodes(String xpathStr) throws XPathExpressionException {
		XPathFactory xPathfactory = XPathFactory.newInstance();
		XPath xpath = xPathfactory.newXPath();
		XPathExpression expr = xpath.compile(xpathStr);
		NodeList nodes = (NodeList) expr.evaluate(this.document,
				XPathConstants.NODESET);
		return nodes;
	}
}
