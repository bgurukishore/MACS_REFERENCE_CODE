package com.dio.anttasks;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

public class FixupClasspathTask extends Task {

	private File workspace = null;
	private String var = null;

	@Override
	public void execute() throws BuildException {
		super.execute();
		DirectoryScanner ds = new DirectoryScanner();
		ds.setIncludes(new String[] { "**\\.classpath" });
		ds.setBasedir(workspace);
		ds.setCaseSensitive(false);
		ds.scan();
		List<String> lines = null;
		String value = System.getenv(var).replace('\\', '/');
		try {
			for (String filename : ds.getIncludedFiles()) {
				File classpathFile = new File(workspace, filename);
				log("Checking " + classpathFile.getAbsolutePath(),
						Project.MSG_INFO);
				lines = FileUtils.readLines(classpathFile,
						Charset.defaultCharset());
				for (int i = 0; i < lines.size(); i++) {
					if (lines.get(i).contains(var)) {
						log("-> Changed " + lines.get(i).trim(),
								Project.MSG_INFO);
						lines.set(i, lines.get(i).replaceAll(var, value)
								.replace("kind=\"var\"", "kind=\"lib\""));
						log("\tto " + lines.get(i).trim(), Project.MSG_INFO);
					}
				}
				FileUtils.writeLines(classpathFile, lines);
			}
		} catch (IOException e) {
			throw new BuildException(e);
		}
	}

	public File getWorkspace() {
		return workspace;
	}

	public void setWorkspace(File workspace) {
		this.workspace = workspace;
	}

	public String getVar() {
		return var;
	}

	public void setVar(String var) {
		this.var = var;
	}

}
