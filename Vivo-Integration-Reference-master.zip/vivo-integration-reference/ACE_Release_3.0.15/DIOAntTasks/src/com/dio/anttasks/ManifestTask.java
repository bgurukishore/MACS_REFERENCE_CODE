package com.dio.anttasks;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

public class ManifestTask extends Task {
	private File manifestFile = null;

	@Override
	public void execute() throws BuildException {
		super.execute();
		if (manifestFile == null) {
			throw new BuildException("No manifest file was specified.");
		}
		log("Writing to " + manifestFile.getAbsolutePath(), Project.MSG_INFO);
		StringWriter out = new StringWriter();
		PrintWriter writer = new PrintWriter(out);
		writer.println("Date: "
				+ new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
						.format(new Date()));
		writer.println("Built-by: " + System.getenv("USERNAME"));
		if ("TRUE".equalsIgnoreCase(getProject().getProperty("release_build"))) {
			writer.println("Release: " + getProject().getProperty("svn_tag"));
		}
		String svnversion = getProject().getProperty("svnversion");
		if (StringUtils.isNotBlank(svnversion)) {
			writer.println("svnversion: " + svnversion);
		}
		SvnInfoTask task = new SvnInfoTask();
		task.setProject(this.getProject());
		task.execute();
		writer.write(task.getOutput());
		writer.println();
		writer.println(StringUtils.repeat('-', 78));
		DirectoryScanner ds = new DirectoryScanner();
		ds.setIncludes(new String[] { "**\\*" });
		ds.setExcludes(new String[] { manifestFile.getName() });
		ds.setBasedir(manifestFile.getParentFile());
		ds.setCaseSensitive(false);
		ds.scan();
		for (String filename : ds.getIncludedFiles()) {
			writer.println(filename);
		}
		try {
			manifestFile.getParentFile().mkdirs();
			FileUtils.write(manifestFile, out.toString(),
					Charset.defaultCharset());
		} catch (IOException e) {
			throw new BuildException(e);
		}
	}

	public File getFile() {
		return manifestFile;
	}

	public void setFile(String manifestFile) {
		setFile(new File(manifestFile));
	}

	public void setFile(File manifestFile) {
		this.manifestFile = manifestFile;
	}

}
