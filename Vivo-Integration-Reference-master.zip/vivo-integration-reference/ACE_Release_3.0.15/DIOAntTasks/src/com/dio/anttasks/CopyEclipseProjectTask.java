package com.dio.anttasks;

import java.io.File;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;

import com.dio.utils.EclipseProject;
import com.dio.utils.EclipseWorkspace;

public class CopyEclipseProjectTask extends Task {
	private String projectName = null;
	private File sourceWorkspace = null;
	private File targetWorkspace = null;

	@Override
	public void execute() throws BuildException {
		super.execute();
		if (StringUtils.isBlank(projectName)) {
			throw new BuildException(
					"'projectName' must be set as the name of the project you wish to use as the primary.");
		}
		if (targetWorkspace == null || !targetWorkspace.isDirectory()) {
			throw new BuildException(
					"'targetWorkspace' must be set as the target location for the copy.");
		}
		if (sourceWorkspace == null || !sourceWorkspace.isDirectory()) {
			throw new BuildException(
					"'sourceWorkspace' must be set as the source location for the copy.");
		}
		EclipseWorkspace eclipseWorkspace = new EclipseWorkspace(
				sourceWorkspace);
		EclipseProject eclipseProject = eclipseWorkspace.getEclipseProjects()
				.get(projectName);
		Set<EclipseProject> copySet = new TreeSet<EclipseProject>();
		copySet.add(eclipseProject);
		copySet.addAll(eclipseProject.getDependencies());
		copySet.forEach((EclipseProject t) -> {
			try {
				File dest = new File(targetWorkspace, t.getName());
				log("Copying '" + t.getProjectDir() + "' to '" + dest + "'.",
						Project.MSG_INFO);
				FileUtils.copyDirectory(t.getProjectDir(), dest);
			} catch (Exception e) {
				throw new BuildException(e);
			}
		});
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public File getSourceWorkspace() {
		return sourceWorkspace;
	}

	public void setSourceWorkspace(File sourceWorkspace) {
		this.sourceWorkspace = sourceWorkspace;
	}

	public File getTargetWorkspace() {
		return targetWorkspace;
	}

	public void setTargetWorkspace(File targetWorkspace) {
		this.targetWorkspace = targetWorkspace;
	}

}
