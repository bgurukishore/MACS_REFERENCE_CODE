package com.dio.anttasks._abstract;

import java.io.File;

import org.apache.tools.ant.Task;

import com.dio.utils.EclipseWorkspace;

public abstract class EclipseWorkspaceBasedTask extends Task {
	private File workspace = null;
	private EclipseWorkspace eclipseWorkspace = null;

	public File getWorkspace() {
		return workspace;
	}

	public void setWorkspace(String workspace) {
		setWorkspace(new File(workspace));
	}

	public void setWorkspace(File workspace) {
		this.workspace = workspace;
		eclipseWorkspace = new EclipseWorkspace(this.workspace);
	}

	public EclipseWorkspace getEclipseWorkspace() {
		return eclipseWorkspace;
	}

}
