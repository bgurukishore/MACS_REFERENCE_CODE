package com.dio.anttasks._abstract;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.commons.lang3.StringUtils;
import org.apache.tools.ant.BuildException;

public abstract class SvnAbstractBaseTask extends CmdLineAbstractTask {
	private URI url = null;

	public URI getUrl() {
		return url;
	}

	public void setUrl(URI url) {
		this.url = url;
	}

	public void setUrl(String url) {
		try {
			this.url = new URI(url);
		} catch (URISyntaxException e) {
			throw new BuildException(e);
		}
	}

	public URI getTrunkUrl() {
		String trunkUrl = this.getProject().getProperty("svn_trunk_url");
		if (StringUtils.isBlank(trunkUrl)) {
			throw new BuildException("svn_trunk_url is not defined.");
		}
		try {
			return new URI(trunkUrl);
		} catch (URISyntaxException e) {
			throw new BuildException(e);
		}
	}

	public URI getBranchUrl() {
		String branchUrl = this.getProject().getProperty("svn_branch_url");
		if (StringUtils.isBlank(branchUrl)) {
			throw new BuildException("svn_branch_url is not defined.");
		}
		try {
			return new URI(branchUrl);
		} catch (URISyntaxException e) {
			throw new BuildException(e);
		}
	}

	public URI getBranchUrl(String branchName) {
		String branchUrl = getBranchUrl().toString();
		if (StringUtils.endsWith(branchUrl, "/")) {
			branchUrl = String.format("%s%s", branchUrl, branchName);
		} else {
			branchUrl = String.format("%s/%s", branchUrl, branchName);
		}
		try {
			return new URI(branchUrl);
		} catch (URISyntaxException e) {
			throw new BuildException(e);
		}
	}

	public URI getReleaseUrl() {
		String releaseUrl = this.getProject().getProperty("svn_release_url");
		if (StringUtils.isBlank(releaseUrl)) {
			throw new BuildException("svn_release_url is not defined.");
		}
		try {
			return new URI(releaseUrl);
		} catch (URISyntaxException e) {
			throw new BuildException(e);
		}
	}
}
