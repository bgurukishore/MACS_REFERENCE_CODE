package com.dio.anttasks;

import java.io.File;
import java.io.IOException;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;

import com.dio.anttasks._abstract.SvnAbstractBaseTask;
import com.dio.utils.RegExpHelper;

public class SvnVersionTask extends SvnAbstractBaseTask {
	private String revision = null;
	private File path = null;

	@Override
	public void execute() throws BuildException {
		super.execute();
		cmd.setExecutable("svnversion", true);
		cmd.createArgument().setValue(getPath().getAbsolutePath());
		int retval = 0;
		try {
			retval = runCommand();
			getProject().setProperty("svnversion",
					RegExpHelper.find(getOutput(), "([\\w]*).*", 1));
			log("svnversion = " + getProject().getProperty("svnversion"),
					Project.MSG_INFO);
		} catch (IOException e) {
			throw new BuildException("The 'svn info' task failed.", e);
		}
	}

	public String getRevision() {
		return revision;
	}

	public void setRevision(String revision) {
		this.revision = revision;
	}

	public File getPath() {
		return path;
	}

	public void setPath(File path) {
		this.path = path;
	}

}
