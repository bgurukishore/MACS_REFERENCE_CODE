package com.dio.anttasks;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

import org.apache.commons.lang3.StringUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;

import com.dio.anttasks._abstract.SvnAbstractBaseTask;
import com.dio.utils.EclipseProject;
import com.dio.utils.EclipseWorkspace;
import com.dio.utils.RegExpHelper;

public class DeployLogSqlScriptTask extends SvnAbstractBaseTask {
	private String projectName = null;
	private EclipseWorkspace eclipseWorkspace = null;
	private EclipseProject eclipseProject = null;

	@Override
	public void execute() throws BuildException {
		super.execute();
		String objectVers = StringUtils.EMPTY;
		eclipseWorkspace = new EclipseWorkspace(getWorkspace());
		eclipseProject = eclipseWorkspace.getEclipseProjects().get(
				getProjectName());
		cmd.setExecutable("svn");
		cmd.createArgument().setValue("info");
		cmd.createArgument().setValue(
				getProject().getProperty("toolkit_workspace_loc"));
		cmd.createArgument().setValue("--show-item");
		cmd.createArgument().setValue("url");
		int retval = 0;
		try {
			retval = runCommand();
			log(getOutput(), Project.MSG_INFO);
			URI uri = URI.create(getOutput().replaceAll("\\s",
					StringUtils.EMPTY));
			String uriPath = uri.getPath();
			if (uriPath.contains("/trunk")) {
				objectVers = getProject().getProperty("svnversion");
			} else if (uriPath.contains("/tags")) {
				objectVers = StringUtils.defaultString(RegExpHelper.find(
						uriPath, "[\\/]{0,1}tags\\/([\\w\\.]*)", 1),
						StringUtils.EMPTY);
			} else if (uri.getPath().contains("/branches")) {
				objectVers = StringUtils.defaultString(RegExpHelper.find(
						uriPath, "[\\/]{0,1}branches\\/([\\w\\.]*)", 1),
						StringUtils.EMPTY)
						+ " (branch)";
			}
			File deploySqlFile = new File(eclipseProject.getSqlDir(),
					"deployLogSqlScript.template");
			log("Writing " + deploySqlFile.getAbsolutePath(), Project.MSG_INFO);
			try (PrintWriter out = new PrintWriter(
					new FileWriter(deploySqlFile))) {
				// out.println("USE ESB");
				// out.println("GO");
				// out.println("");
				// out.println("IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[DEPLOY_LOG]') AND type in (N'U'))");
				// out.println("	CREATE TABLE [dbo].[DEPLOY_LOG](");
				// out.println("		[INTEGRATION_NODE] [varchar](250) NULL,");
				// out.println("		[INTEGRATION_SERVER] [varchar](250) NULL,");
				// out.println("		[OBJECT_NAME] [varchar](250) NULL,");
				// out.println("		[OBJECT_VERS] [varchar](50) NULL,");
				// out.println("		[BUILD_TIME] [datetimeoffset](7) NULL,");
				// out.println("		[BUILT_BY] [varchar](250) NULL,");
				// out.println("		[DEPLOY_TIME] [datetimeoffset](7) NULL,");
				// out.println("		[DEPLOYED_BY] [varchar](250) NULL");
				// out.println("	) ON [PRIMARY]");
				// out.println("	GO");
				// out.println("");
				out.println("MERGE DEPLOY_LOG AS target");
				out.println("USING (");
				out.println("	SELECT '____IntegrationNode____'");
				out.println("		,'____IntegrationServer____'");
				out.println("		,'" + getProjectName() + "'");
				out.println("		,'" + objectVers + "'");
				out.println("		,'"
						+ new SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss.SSS")
								.format(Calendar.getInstance().getTime())
						+ "'");
				out.println("		,'" + System.getenv("USERNAME") + "'");
				out.println("		,GETUTCDATE()");
				out.println("		,'____UserName____'");
				out.println("	) AS source(INTEGRATION_NODE, INTEGRATION_SERVER, OBJECT_NAME, OBJECT_VERS, BUILD_TIME, BUILT_BY, DEPLOY_TIME, DEPLOYED_BY)");
				out.println("	ON (target.INTEGRATION_NODE = source.INTEGRATION_NODE AND target.INTEGRATION_SERVER = source.INTEGRATION_SERVER AND target.OBJECT_NAME = source.OBJECT_NAME)");
				out.println("WHEN MATCHED");
				out.println("	THEN");
				out.println("		UPDATE SET OBJECT_VERS = source.OBJECT_VERS,BUILD_TIME = source.BUILD_TIME,BUILT_BY = source.BUILT_BY,DEPLOY_TIME = source.DEPLOY_TIME,DEPLOYED_BY = source.DEPLOYED_BY");
				out.println("WHEN NOT MATCHED");
				out.println("	THEN");
				out.println("		INSERT (INTEGRATION_NODE,INTEGRATION_SERVER,OBJECT_NAME,OBJECT_VERS,BUILD_TIME,BUILT_BY,DEPLOY_TIME,DEPLOYED_BY)");
				out.println("		VALUES (source.INTEGRATION_NODE,source.INTEGRATION_SERVER,source.OBJECT_NAME,source.OBJECT_VERS,source.BUILD_TIME,source.BUILT_BY,source.DEPLOY_TIME,source.DEPLOYED_BY);");
			}
		} catch (IOException e) {
			throw new BuildException("The 'svn info' task failed.", e);
		}
	}

	public File getWorkspace() {
		return workingDirectory;
	}

	public void setWorkspace(File workspace) {
		this.workingDirectory = workspace;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
}
