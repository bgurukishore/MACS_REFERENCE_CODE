package com.dio.anttasks;

import java.io.File;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;

import com.dio.anttasks._abstract.EclipseWorkspaceBasedTask;
import com.dio.utils.EclipseProject;

public class ConfigureBuilderTask extends EclipseWorkspaceBasedTask {
	private File projectDir = null;
	private EclipseProject eclipseProject = null;

	@Override
	public void execute() throws BuildException {
		super.execute();
		if (projectDir == null) {
			throw new BuildException("No project directory has been set.");
		}
		boolean developer_build = "TRUE".equalsIgnoreCase(getProject()
				.getProperty("developer_build"));
		boolean release_build = "TRUE".equalsIgnoreCase(getProject()
				.getProperty("release_build"));
		if (!developer_build && !release_build) {
			getProject().setProperty("developer_build", Boolean.toString(true));
			getProject().setProperty("release_build", Boolean.toString(false));
			log("*** WARNING *** : Defaulting to developer (or working copy) build...",
					Project.MSG_WARN);
			log("\tSpecify -Ddeveloper_build=true as an argument to remove this warning.",
					Project.MSG_WARN);
		}
		eclipseProject = new EclipseProject(new File(projectDir, ".project"));
		setWorkspace(projectDir.getParentFile());
		//
		getProject().setProperty("toolkit_workspace_loc",
				getWorkspace().getAbsolutePath());
		log("toolkit_workspace_loc = "
				+ getProject().getProperty("toolkit_workspace_loc"),
				Project.MSG_INFO);
		//
		getProject().setProperty("package_extension", ".zip");
		log("package_extension = "
				+ getProject().getProperty("package_extension"),
				Project.MSG_INFO);
		//
		getProject().setProperty("package_basename", eclipseProject.getName());
		log("package_basename = "
				+ getProject().getProperty("package_basename"),
				Project.MSG_INFO);
		//
		getProject().setProperty(
				"package_name",
				getProject().getProperty("package_basename")
						+ getProject().getProperty("package_extension"));
		log("package_name = " + getProject().getProperty("package_name"),
				Project.MSG_INFO);
		//
		getProject().setProperty("eclipse_project_dist_loc",
				eclipseProject.getDistDir().getAbsolutePath());
		if (!eclipseProject.getDistDir().isDirectory()) {
			eclipseProject.getDistDir().mkdirs();
		}
		log("eclipse_project_dist_loc = "
				+ getProject().getProperty("eclipse_project_dist_loc"),
				Project.MSG_INFO);
		//
		getProject().setProperty("eclipse_project_build_loc",
				eclipseProject.getBuildDir().getAbsolutePath());
		if (!eclipseProject.getBuildDir().isDirectory()) {
			eclipseProject.getBuildDir().mkdirs();
		}
		log("eclipse_project_build_loc = "
				+ getProject().getProperty("eclipse_project_build_loc"),
				Project.MSG_INFO);
	}

	public File getProjectDir() {
		return projectDir;
	}

	public void setProjectDir(String projectDir) {
		setProjectDir(new File(projectDir));
	}

	public void setProjectDir(File projectDir) {
		this.projectDir = projectDir;
	}

}
