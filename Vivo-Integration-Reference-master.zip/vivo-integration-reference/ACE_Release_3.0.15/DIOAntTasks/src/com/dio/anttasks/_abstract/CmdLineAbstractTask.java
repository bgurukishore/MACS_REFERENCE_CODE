package com.dio.anttasks._abstract;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.lang3.time.StopWatch;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.taskdefs.Execute;
import org.apache.tools.ant.taskdefs.ExecuteWatchdog;
import org.apache.tools.ant.taskdefs.PumpStreamHandler;
import org.apache.tools.ant.types.Commandline;

public abstract class CmdLineAbstractTask extends Task {

	protected static final long DEFAULT_TIMEOUT = 300000;

	protected final Commandline cmd = new Commandline();
	protected File workingDirectory = null;
	protected final OutputStream out = new ByteArrayOutputStream();
	protected final OutputStream err = new ByteArrayOutputStream();

	protected int runCommand() throws IOException {
		final PumpStreamHandler pumpStreamHandler = new PumpStreamHandler(out,
				err);
		final Execute runner = new Execute(pumpStreamHandler,
				new ExecuteWatchdog(DEFAULT_TIMEOUT));
		runner.setAntRun(getProject());
		runner.setWorkingDirectory(workingDirectory);
		runner.setCommandline(cmd.getCommandline());
		log(cmd.toString(), Project.MSG_INFO);
		final StopWatch sw = new StopWatch();
		sw.start();
		int execute = runner.execute();
		sw.stop();
		log("Time taken = " + sw.toString());
		return execute;
	}

	protected void reset() {
		((ByteArrayOutputStream) out).reset();
		((ByteArrayOutputStream) err).reset();
		cmd.clear();
	}

	public String getOutput() {
		return out.toString();
	}
}
