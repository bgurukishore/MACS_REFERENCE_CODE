package com.dio.anttasks;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.zip.ZipFile;

import com.dio.anttasks._abstract.CmdLineAbstractTask;
import com.dio.utils.EclipseProject;
import com.dio.utils.EclipseWorkspace;

public class CreateBarTask extends CmdLineAbstractTask {

	private static final File mqsicreatebar;
	static {
		mqsicreatebar = new File(new File(System.getenv("MQSI_BASE_FILEPATH"),
				"tools"), "mqsicreatebar");
	}

	private String projectName = null;
	private EclipseWorkspace eclipseWorkspace = null;
	private EclipseProject eclipseProject = null;
	private File pkgDir = null;
	private File buildDir = null;
	private File distDir = null;
	private boolean esql21 = false;
	private boolean cleanBuild = true;
	private String version = null;
	private boolean skipWSErrorCheck = false;
	private boolean trace = false;
	private boolean deployAsSource = true;
	private boolean compileOnly = false;
	private File traceFilePath = null;

	@Override
	public void execute() throws BuildException {
		super.execute();
		eclipseWorkspace = new EclipseWorkspace(getWorkspace());
		eclipseProject = eclipseWorkspace.getEclipseProjects().get(
				getProjectName());
		log("Building " + getProjectName(), Project.MSG_INFO);
		pkgDir = eclipseProject.getPackageDir();
		if (!pkgDir.isDirectory()) {
			throw new BuildException(
					"Missing package directory for the project [" + pkgDir
							+ "].");
		}
		buildDir = eclipseProject.getBuildDir();
		if (!buildDir.isDirectory()) {
			if (!buildDir.mkdirs()) {
				throw new BuildException(
						"Could not create build directory for the project ["
								+ buildDir + "].");
			}
		}
		distDir = eclipseProject.getDistDir();
		if (!distDir.isDirectory()) {
			if (!distDir.mkdirs()) {
				throw new BuildException(
						"Could not create distribution directory for the project ["
								+ distDir + "].");
			}
		}
		try {
			log("Cleaning " + buildDir, Project.MSG_VERBOSE);
			FileUtils.cleanDirectory(buildDir);
		} catch (IOException e) {
			throw new BuildException(e);
		}
		try {
			log("Cleaning " + distDir, Project.MSG_VERBOSE);
			FileUtils.cleanDirectory(distDir);
		} catch (IOException e) {
			throw new BuildException(e);
		}
		try {
			log("Copying " + pkgDir + " to " + buildDir, Project.MSG_VERBOSE);
			FileUtils.copyDirectory(pkgDir, buildDir);
		} catch (Exception e) {
			throw new BuildException(e);
		}
		createBar(eclipseProject);
		// eclipseProject.getDependencies().forEach(
		// (EclipseProject ep) -> createBar(ep));
	}

	private void createBar(EclipseProject eclipseProject) {
		if (!(eclipseProject.isACEApplication()
				|| eclipseProject.isACESharedLibrary() || eclipseProject
					.isACEPolicyProject())) {
			log("Project is not an Application, Share Library or Policy. ["
					+ eclipseProject.getName() + "]", Project.MSG_WARN);
			return;
		}
		File barFile = new File(new File(buildDir, "barfiles"),
				eclipseProject.getName() + ".bar");
		getProject().setProperty("barfile", barFile.getAbsolutePath());
		List<String> referencedProjects = eclipseProject
				.getReferencedProjects();
		log("Creating " + barFile, Project.MSG_VERBOSE);
		cmd.clear();
		cmd.setExecutable(mqsicreatebar.getAbsolutePath(), true);
		cmd.createArgument().setValue("-data");
		cmd.createArgument().setValue(getWorkspace().getAbsolutePath());
		cmd.createArgument().setValue("-b");
		cmd.createArgument().setValue(barFile.getAbsolutePath());
		if (isCleanBuild()) {
			cmd.createArgument().setValue("-cleanBuild");
		}
		if (StringUtils.isNotBlank(getVersion())) {
			cmd.createArgument().setValue("-version");
			cmd.createArgument().setValue(getVersion());
		}
		if (isEsql21()) {
			cmd.createArgument().setValue("-esql21");
		}
		if (eclipseProject.isACEApplication()) {
			cmd.createArgument().setValue("-a");
			cmd.createArgument().setValue(eclipseProject.getName());
		}
		if (eclipseProject.isACESharedLibrary()) {
			cmd.createArgument().setValue("-l");
			cmd.createArgument().setValue(eclipseProject.getName());
		}
		if (eclipseProject.isACEPolicyProject()) {
			cmd.createArgument().setValue("-x");
			cmd.createArgument().setValue(eclipseProject.getName());
			if (!referencedProjects.contains(eclipseProject.getName())) {
				referencedProjects.add(eclipseProject.getName());
			}
		}
		if (!referencedProjects.isEmpty()) {
			cmd.createArgument().setValue("-p");
			for (String artefact : referencedProjects) {
				cmd.createArgument().setValue(artefact);
			}
		}
		if (isDeployAsSource()) {
			cmd.createArgument().setValue("-deployAsSource");
		}
		if (isCompileOnly()) {
			cmd.createArgument().setValue("-compileOnly");
		}
		if (isTrace()) {
			cmd.createArgument().setValue("-trace");
		}
		int retval = 0;
		try {
			retval = runCommand();
		} catch (IOException e) {
			throw new BuildException("The mqsicreatebar task failed.", e);
		}
		if (retval == 0) {
			if (barFile.exists()) {
				log(":-) '" + barFile.getAbsolutePath()
						+ "' succesfully created.", Project.MSG_INFO);
				log("Added 'barfile' property to project as "
						+ getProject().getProperty("barfile"), Project.MSG_INFO);
				if (getTraceFilePath() != null && getTraceFilePath().isFile()) {
					try {
						log(FileUtils.readFileToString(getTraceFilePath(),
								Charset.defaultCharset()), Project.MSG_VERBOSE);
					} catch (IOException e) {
						log(e.getLocalizedMessage(), Project.MSG_ERR);
					}
					// getTraceFilePath().delete();
				}
				if ("TRUE".equalsIgnoreCase(getProject().getProperty(
						"developer_build"))) {
					invokeReadBarTask(barFile);
				}
			} else {
				log(":-| The create BAR task completed successfully, but couldn't find the BAR file..",
						Project.MSG_WARN);
			}
		} else {
			log(":-( " + barFile.getAbsolutePath() + " was NOT created.",
					Project.MSG_ERR);
			try {
				if (getTraceFilePath() != null) {
					log(FileUtils.readFileToString(getTraceFilePath(),
							Charset.defaultCharset()), Project.MSG_ERR);
				}
			} catch (IOException e) {
				log(e.getLocalizedMessage(), Project.MSG_ERR);
			}
			throw new BuildException("The mqsicreatebar task failed.");
		}
	}

	private void invokeReadBarTask(File barFile) {
		File targetDir = new File(getProject().getProperty("build_loc"));
		ReadBarTask readBarTask = new ReadBarTask();
		readBarTask.setProject(this.getProject());
		readBarTask.setTaskName("ReadBarTask");
		readBarTask.setBarFile(barFile);
		readBarTask.setOverridesFile(new File(targetDir, FilenameUtils
				.getBaseName(barFile.getName()) + ".txt"));
		readBarTask.execute();
	}

	public File getWorkspace() {
		return workingDirectory;
	}

	public void setWorkspace(File workspace) {
		this.workingDirectory = workspace;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public boolean isCleanBuild() {
		return cleanBuild;
	}

	public void setCleanBuild(boolean cleanBuild) {
		this.cleanBuild = cleanBuild;
	}

	public boolean isEsql21() {
		return esql21;
	}

	public void setEsql21(boolean esql21) {
		this.esql21 = esql21;
	}

	public boolean isSkipWSErrorCheck() {
		return skipWSErrorCheck;
	}

	public void setSkipWSErrorCheck(boolean skipWSErrorCheck) {
		this.skipWSErrorCheck = skipWSErrorCheck;
	}

	public boolean isTrace() {
		return trace;
	}

	public void setTrace(boolean trace) {
		this.trace = trace;
	}

	public boolean isDeployAsSource() {
		return deployAsSource;
	}

	public void setDeployAsSource(boolean deployAsSource) {
		this.deployAsSource = deployAsSource;
	}

	public boolean isCompileOnly() {
		return compileOnly;
	}

	public void setCompileOnly(boolean compileOnly) {
		this.compileOnly = compileOnly;
	}

	public File getTraceFilePath() {
		return traceFilePath;
	}

	public void setTraceFilePath(File traceFilePath) {
		this.traceFilePath = traceFilePath;
	}

}
