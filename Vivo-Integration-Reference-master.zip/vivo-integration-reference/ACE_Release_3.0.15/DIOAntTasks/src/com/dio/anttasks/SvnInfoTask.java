package com.dio.anttasks;

import java.io.File;
import java.io.IOException;

import org.apache.tools.ant.BuildException;

import com.dio.anttasks._abstract.SvnAbstractBaseTask;

public class SvnInfoTask extends SvnAbstractBaseTask {
	private String revision = null;
	private File destDir = null;
	private boolean followDependencies = true;

	@Override
	public void execute() throws BuildException {
		super.execute();
		// if (StringUtils.isBlank(revision)) {
		// throw new BuildException("No svn revision specified.");
		// }
//		if (destDir == null) {
//			throw new BuildException("No destination directory specified.");
//		}
		cmd.clear();
		cmd.setExecutable("svn", true);
		cmd.createArgument().setValue("info");
		int retval = 0;
		try {
			retval = runCommand();
		} catch (IOException e) {
			throw new BuildException("The 'svn info' task failed.", e);
		}
	}

	public String getRevision() {
		return revision;
	}

	public void setRevision(String revision) {
		this.revision = revision;
	}

	public File getDestDir() {
		return destDir;
	}

	public void setDestDir(String destDir) {
		setDestDir(new File(destDir));
	}

	public void setDestDir(File destDir) {
		this.destDir = destDir;
	}

	public boolean isFollowDependencies() {
		return followDependencies;
	}

	public void setFollowDependencies(boolean followDependencies) {
		this.followDependencies = followDependencies;
	}

}
