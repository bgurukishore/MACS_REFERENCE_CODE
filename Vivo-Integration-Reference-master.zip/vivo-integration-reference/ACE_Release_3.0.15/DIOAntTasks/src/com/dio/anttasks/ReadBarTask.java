package com.dio.anttasks;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.FileUtils;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;

import com.dio.anttasks._abstract.CmdLineAbstractTask;

public class ReadBarTask extends CmdLineAbstractTask {
	private static final File mqsireadbar;
	static {
		mqsireadbar = new File(new File(new File(
				System.getenv("MQSI_BASE_FILEPATH"), "server"), "bin"),
				"mqsireadbar.bat");
	}

	private File barFile = null;
	private boolean recursive = true;
	private File traceFile = null;
	private File overridesFile = null;

	@Override
	public void execute() throws BuildException {
		super.execute();
		log("Reading " + barFile, Project.MSG_VERBOSE);
		cmd.clear();
		cmd.setExecutable(mqsireadbar.getAbsolutePath(), true);
		cmd.createArgument().setValue("-b");
		cmd.createArgument().setValue(barFile.getAbsolutePath());
		if (recursive) {
			cmd.createArgument().setValue("-r");
		}
		if (traceFile != null) {
			cmd.createArgument().setValue("-v");
			cmd.createArgument().setValue(traceFile.getAbsolutePath());
		}
		int retval = 0;
		try {
			retval = runCommand();
		} catch (IOException e) {
			throw new BuildException("The mqsireadbar task failed.", e);
		}
		if (retval == 0) {
			log(":-) '" + barFile.getAbsolutePath() + "' succesfully read.",
					Project.MSG_INFO);
			try {
				FileUtils.write(overridesFile, getOutput(),
						StandardCharsets.UTF_8);
				log("Written default overrides file: "
						+ overridesFile.getAbsolutePath(), Project.MSG_INFO);
			} catch (IOException e) {
				throw new BuildException(e);
			}
		} else {
			log(":-( " + barFile.getAbsolutePath() + " was NOT read.",
					Project.MSG_ERR);
			throw new BuildException("The mqsireadbar task failed.");
		}
	}

	public File getBarFile() {
		return barFile;
	}

	public void setBarFile(File barFile) {
		this.barFile = barFile;
	}

	public boolean isRecursive() {
		return recursive;
	}

	public void setRecursive(boolean recursive) {
		this.recursive = recursive;
	}

	public File getTraceFile() {
		return traceFile;
	}

	public void setTraceFile(File traceFile) {
		this.traceFile = traceFile;
	}

	public File getOverridesFile() {
		return overridesFile;
	}

	public void setOverridesFile(File overridesFile) {
		this.overridesFile = overridesFile;
	}

}
