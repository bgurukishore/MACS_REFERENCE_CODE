package com.dio.anttasks;

import java.io.File;

import org.apache.tools.ant.Project;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CreateBarTaskTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		CreateBarTask task = new CreateBarTask();
		task.setProject(new Project());
		// <createbar workspace="${workspace_loc}" barname="AuditWriter"
		// applicationName="AuditWriter" trace="on" />
		task.setWorkspace(new File(
				"C:\\Users\\ma_p_sharpe\\IBM\\ACET11\\build\\build.time"));
		task.setProjectName("AuditWriter");
		task.execute();
	}

}
