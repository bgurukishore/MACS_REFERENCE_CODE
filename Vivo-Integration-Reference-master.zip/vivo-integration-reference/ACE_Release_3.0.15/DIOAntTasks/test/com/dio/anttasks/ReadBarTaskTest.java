package com.dio.anttasks;

import java.io.File;

import org.apache.tools.ant.Project;
import org.junit.Test;

public class ReadBarTaskTest {

	@Test
	public void test() {
		ReadBarTask task = new ReadBarTask();
		task.setProject(new Project());
		task.setBarFile(new File(
				"C:\\Users\\ma_Philip_Sharpe\\workspaces\\CAFM_trunk\\GeneratedBarFiles",
				"IP_DocumentStorer_MXproject.generated.bar"));
		task.setOverridesFile(new File(
				"C:\\Users\\ma_Philip_Sharpe\\workspaces\\CAFM_trunk\\GeneratedBarFiles",
				"IP_DocumentStorer_MX_ENV.txt"));
		task.execute();
	}

}
