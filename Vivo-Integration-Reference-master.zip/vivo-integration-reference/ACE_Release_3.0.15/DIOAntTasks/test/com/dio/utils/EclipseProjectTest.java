package com.dio.utils;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class EclipseProjectTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() throws Exception {
		EclipseProject ep = new EclipseProject(
				new File(
						"C:\\Users\\ma_p_sharpe\\IBM\\ACET11\\src\\FMCDE\\AuditWriter\\trunk\\AuditWriter\\.project"));
		System.out.println(ep.getName());
		System.out.println(ep.getReferencedProjects());
	}

}
