# Exception Message Numbers (2951 through 2999)
2951 - Die
2952 - AssertTrue => Failed
2953 - AssertFalse => Failed
2954 - ThrowUserException

2999 - Re-throw exception from simple catch handler

# Audit Functions
In all cases, `auditEventGroupId` is a grouping identifier and should be specified as `GetEsbTransactionId(Root)`.

## AuditEvent(IN auditEventGroupId CHAR, IN auditEventType CHAR, IN auditEventText CHAR)
This is a simple audit event, only the event type and text are provided.

	CALL AuditEvent(GetEsbTransactionId(OutputRoot), 'ACQUIRED', 'Acquired from source queue: ' || TRIM(OutputRoot.MQMD.SourceQueue));

## AuditEventForUpdate(IN auditEventGroupId CHAR, IN auditEventType CHAR, IN auditEventText CHAR, OUT auditLogId CHAR)
This is a audit event for which you intend to provide an update for at some later time within the message flow. You store the `auditLogId` for later use (as a primary key) against which to perform the update.

	DECLARE auditLogId CHAR NULL;
	CALL AuditEventForUpdate(GetEsbTransactionId( OutputRoot), 'ACQUIRED', 'SoN Request', auditLogId);
	CALL SetMessageFlowAuditId(InputRoot, auditLogId);
		
## AuditEventUpdate(IN auditEventGroupId CHAR, IN auditEventType CHAR, IN auditEventText CHAR, IN auditLogId CHAR, IN outcome CHAR, IN sourceUser CHAR, IN sourceSystemMessageId CHAR, IN sourceSystemId CHAR)
This is an update to a previously logged event.

	DECLARE auditLogId CHAR GetMessageFlowAuditId(InputRoot);
	IF IsNotBlank(auditLogId) THEN
		CALL AuditEventUpdate(GetEsbTransactionId(InputRoot), NULL, NULL, auditLogId, imsoutcome, NULL, NULL, NULL);
	END IF;