package uk.mil.dio.housekeeping;

import java.io.IOException;
import java.net.URI;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystem;
import java.nio.file.FileSystemAlreadyExistsException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
/*
 *  HousekeepingHelper
 *  
 *  Contains helper functions for managing logs
 */
public class HousekeepingHelper {
	/*
	 * @logPath - String, the location of the files to be zipped/deleted
	 * @logPattern - String - a regular expression to ensure only corretc files are captured
	 * @zipExtPattern - String a regular expression that converts the log file name to a zip name so one day of logs is zipped to a single file.
	 *                  e.g. WACE01A_2021-06-09-1.log to WACE01A_2021-06-09.zip
	 *                       WACE01A_2021-06-09-2.log to WACE01A_2021-06-09.zip
	 * @ageDays - Long age in days beyond which log files will be zipped/deleted  
	 */
	public static String zipFilesByPatternFilter(String logPath, String logPattern, String zipExtPattern, Long ageDays){
		final List<Path> result = new ArrayList<>();
		final Path path = Paths.get(logPath);
		
		DirectoryStream.Filter<Path> filter = new PatternDateFilter(logPattern, ageDays);
		try (
			DirectoryStream<Path> stream= Files.newDirectoryStream(path, filter);
				) {
			for (final Path entry: stream)
				result.add(entry);
			stream.close();
		} catch ( IOException e){
			System.out.println(e.getMessage());
			return "%Error%=ERR:103001%Text=%Housekeeping Error processing text files in directory : " + e.getMessage();
		}
		// Sort the array to speed zipping
		result.sort(Comparator
			    .comparing(s -> s));		
		
		 /* Define ZIP File System Properies in HashMap */    
        Map<String, String> zip_properties = new HashMap<>(); 
        /* We want to Create if not present or add if present so set to True */
        zip_properties.put("create", "true");
        /* Specify the encoding as UTF -8 */
        zip_properties.put("encoding", "UTF-8");        
		
	    Iterator i = result.iterator(); 
	      System.out.println("The ArrayList elements are:");
	      while (i.hasNext()) {
	    	  Path activePath = (Path) i.next();
	    	  String fileName = activePath.getFileName().toString();
	    	  System.out.println(fileName);	    	  
	    	  String zipName = activePath.toString().replaceAll(zipExtPattern, ".zip").replace("\\", "/");
	    	  System.out.println(zipName);
	    	  
	    	  //URI zip_disk = URI.create("jar:file:/" + zipName);
	    	  URI zip_disk = URI.create("jar:file:" + zipName);
	          try (FileSystem zipfs = FileSystems.newFileSystem(zip_disk, zip_properties)) {
	              /* Create a Path in ZIP File */
	             Path ZipFilePath = zipfs.getPath(fileName);
	             /* Path where the file to be added resides */
	             Path addNewFile = Paths.get(activePath.toString());  
	             /* Append file to ZIP File */
	             Files.copy(addNewFile,ZipFilePath,StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.COPY_ATTRIBUTES); 
	         } catch (FileSystemAlreadyExistsException e){
	        	 System.out.println(e.getMessage());
	        	 return "%Error%=ERR:103002%Text=%Housekeeping Error processing text files. " + zipName + " " + e.toString();

	      } catch (Exception e) {
	        	 System.out.println(e.getMessage());
	        	 return "%Error%=ERR:103002%Text=%Housekeeping Error processing text files. " + e.toString();
	         }
	         try {
	           Files.delete(activePath);
	         } catch (Exception e){
	        	 System.out.print(e.getMessage());
	        	 return "%Error%=ERR:103002%Text=%Housekeeping Error processing text files. " + e.toString();
	         }
	      }
	      return null;

	}
	
	/*
	 * @logPath - String, the location of the files to be zipped/deleted
	 * @zipPattern - String - a regular expression to ensure only correct files are captured
	 * @ageHours - Long age in hours beyond which zip files will be deleted  
	 */
	public static String deleteZipFiles(String logPath, String zipPattern, Long ageDays){
		final List<Path> result = new ArrayList<>();
		final Path path = Paths.get(logPath);
		
		DirectoryStream.Filter<Path> filter = new PatternDateFilter(zipPattern, ageDays);
		try (
			DirectoryStream<Path> stream= Files.newDirectoryStream(path, filter);
				) {
			for (final Path entry: stream)
				result.add(entry);
			stream.close();
		} catch ( IOException e){
			System.out.println(e.getMessage());
			return "%Error%=ERR:103001%Text=%Housekeeping Error processing text files in directory : " + e.getMessage();
		}
		
	    Iterator i = result.iterator(); 
	      while (i.hasNext()) {
	    	  Path activePath = (Path) i.next();
	    	  try {
		           Files.delete(activePath);
		         } catch (Exception e){
		        	 System.out.print(e.getMessage());
		        	 return "%Error%=ERR:103002%Text=%Housekeeping Error processing text files. " + e.toString();
		         }
	      }
	      return null;
	}
}
