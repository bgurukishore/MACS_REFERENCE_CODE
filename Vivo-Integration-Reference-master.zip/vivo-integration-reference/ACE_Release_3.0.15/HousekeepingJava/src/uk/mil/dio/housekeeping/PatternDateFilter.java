package uk.mil.dio.housekeeping;


import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

public class PatternDateFilter implements DirectoryStream.Filter<Path> {

	private String pattern = null;
	private Long ageDays =0L;
	Instant now = null;
	
	public PatternDateFilter(String pattern, Long ageDays){
	this.ageDays = ageDays;	
	this.pattern = pattern;
	this.now = Instant.now().minus(this.ageDays, ChronoUnit.DAYS); 
	}
	
	@Override
    public boolean accept(final Path entry) throws IOException
    {
        if (!Files.isRegularFile(entry))
            return false;
        if (Files.getLastModifiedTime(entry).toInstant().isAfter(now))
            return false;
        String name = (String) entry.getFileName().toString();
        if (name.matches(pattern))
        	return true;
        return false;
    }
}
