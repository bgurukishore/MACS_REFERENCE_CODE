USE [$(SQLCMDDBNAME)]
GO
DELETE FROM [dbo].[ROUTING_DATA] WHERE MSGFLOW = 'TR_ReInstructWorks_MX'

INSERT INTO [dbo].[ROUTING_DATA] ([MSGFLOW],[FILTER],[ESQL_MODULE],[SEQUENCE],[ROUTING_TABLE],[TARGET_URI],[REPLY_URI])
     VALUES('TR_ReInstructWorks_MX',NULL,'CallOSLCQuery.InlineOSLCQuery.Setup',1,'queue:///OSLC_QUERY?transactional=FALSE', NULL, 'queue:///OSLC_QUERY_RESP?transactional=FALSE&expiry=36000')
INSERT INTO [dbo].[ROUTING_DATA] ([MSGFLOW],[FILTER],[ESQL_MODULE],[SEQUENCE],[ROUTING_TABLE],[TARGET_URI],[REPLY_URI])
     VALUES('TR_ReInstructWorks_MX',NULL,'CallOSLCUpdate.Setup',1,'queue:///OSLC_UPDATE?transactional=FALSE', NULL, 'queue:///OSLC_UPDATE_RESP?transactional=FALSE&expiry=36000')

GO


