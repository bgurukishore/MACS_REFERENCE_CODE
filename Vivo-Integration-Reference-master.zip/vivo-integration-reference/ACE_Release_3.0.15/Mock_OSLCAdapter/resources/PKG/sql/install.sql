USE [$(SQLCMDDBNAME)]
GO

/****** Object:  Table [dbo].[MOCK_OSLCADAPTER]    Script Date: 11/02/2021 11:41:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MOCK_OSLCADAPTER]') AND type in (N'U'))
DROP TABLE [dbo].MOCK_OSLCADAPTER
GO

/****** Object:  Table [dbo].[MOCK_OSLCADAPTER]    Script Date: 11/02/2021 11:41:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].MOCK_OSLCADAPTER(
	[TEST_ID] [nvarchar](50) NOT NULL,
	[MODE] [nvarchar](10) NULL,
	[OSLC_PATH] [nvarchar](250) NOT NULL,
	[OSLC_QUERY] [nvarchar](500) NULL,
	[OSLC_SELECT] [nvarchar](250) NULL,
	[RESPONSE_DATA] [ntext] NOT NULL,
	[HTTP_RESPONSE_CODE] [int] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


