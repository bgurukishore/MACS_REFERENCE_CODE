  USE [$(SQLCMDDBNAME)]
  GO
  DELETE FROM [dbo].[ROUTING_DATA] WHERE MSGFLOW = 'gen.MX_Gateway'

  INSERT INTO [dbo].[ROUTING_DATA] ([MSGFLOW], [FILTER],[ESQL_MODULE],[SEQUENCE],[ROUTING_TABLE],[TARGET_URI],[REPLY_URI])
  VALUES
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',0, 'queue:///MX.UNKNOWN.TR', NULL, NULL),
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',1, 'queue:///MX.SONRQ.TR;queue:///OSLC_UPDATE', NULL, 'queue:///TR.SONRS.MX'),
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',2, 'queue:///MX.UNKNOWN.TR', NULL, NULL),
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',3,  'queue:///MX.UPDATEOPTIONSFIRMPRICE.TR', 'queue:///OSLC_UPDATE', 'queue:///TR.OPTIONSFIRMPRICEACK.MX'),
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',4, 'queue:///MX.UPDATEOPTIONSFIRMPRICE.TR', 'queue:///OSLC_UPDATE', 'queue:///TR.OPTIONSFIRMPRICEACK.MX'),  
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',5,  'queue:///MX.MILESTONES.TR', 'queue:///OSLC_UPDATE','queue:///TR.STATUSACK.MX'),
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',6, 'queue:///MX.NOTIFY.IP', 'queue:///IP_UPDATE', NULL),
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',7,	'queue:///MX.SONRESP.IP', 'queue:///IP_UPDATE', NULL),
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',8,	 'queue:///MX.NOTIFY.IP', 'queue:///IP_UPDATE', NULL),
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',9,	 'queue:///MX.NOTIFY.IP', 'queue:///IP_UPDATE', NULL),
  ('gen.MX_Gateway',NULL, 'postMaximo (Implementation).SetupRouting',10, 'queue:///MX.NOTIFY.IP', 'queue:///IP_UPDATE', NULL);



  