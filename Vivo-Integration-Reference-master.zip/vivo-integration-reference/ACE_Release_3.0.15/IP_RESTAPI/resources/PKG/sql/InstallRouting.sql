  USE [$(SQLCMDDBNAME)]
  GO
  DELETE FROM [dbo].[ROUTING_DATA] WHERE MSGFLOW = 'gen.IP_RESTAPI'

  INSERT INTO [dbo].[ROUTING_DATA] ([MSGFLOW], [FILTER],[ESQL_MODULE],[SEQUENCE],[ROUTING_TABLE],[TARGET_URI],[REPLY_URI])
  VALUES
  ('gen.IP_RESTAPI',NULL, 'getByIdentifier (Implementation).Send Internal ACK',1, 'queue:///ESB.REQINVACK.MX','queue:///OSLC_UPDATE', NULL),
  ('gen.IP_RESTAPI',NULL, 'postLocation (Implementation).MapAndRoute',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.ASSETLD.MX','queue:///OSLC_UPDATE', NULL),
  ('gen.IP_RESTAPI',NULL, 'postAsset (Implementation).RouteToTransform',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.ASSETLD.MX','queue:///OSLC_UPDATE', NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPFirmPrice (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.UPDATEOPTIONSFIRMPRICE.MX', 'queue:///OSLC_UPDATE', NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPOptions (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.UPDATEOPTIONSFIRMPRICE.MX', 'queue:///OSLC_UPDATE', NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPSoNRequest (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.SONRQ.MX', 'queue:///OSLC_UPDATE', NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPWorkComplete (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.MILESTONES.MX', 'queue:///OSLC_UPDATE', NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPWorkStart (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.MILESTONES.MX', 'queue:///OSLC_UPDATE', NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPWorkUpdate (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.MILESTONES.MX', 'queue:///OSLC_UPDATE', NULL),
  ('gen.IP_RESTAPI',NULL, 'postLinkAssetsAndSchedules (Implementation).SetupRouting',1, 'queue:///IP.SCHEDULELINKS.MX;queue:///MX.NOTIFY.IP','queue:///IP_UPDATE',NULL),
  ('gen.IP_RESTAPI',NULL, 'postPlannedTaskSchedules (Implementation).SetupRouting',1, 'queue:///IP.SCHEDULEPLANS.MX;queue:///MX.NOTIFY.IP','queue:///IP_UPDATE',NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPWorkVariation (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.WORKVARIATION.MX','queue:///OSLC_UPDATE',NULL),
  ('gen.IP_RESTAPI',NULL, 'getByIdentifier (Implementation).Send Internal ACK',2, 'queue:///OSLC_UPDATE', NULL, NULL),
  ('gen.IP_RESTAPI',NULL, 'putIPWorkOrderNoncore (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.WORKORDER.MX',NULL,NULL),
  ('gen.IP_RESTAPI',NULL, 'putIPWorkOrderQuote (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.WORKORDER.MX',NULL,NULL),
  ('gen.IP_RESTAPI',NULL, 'putIPWorkOrderReactive (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.WORKORDER.MX',NULL,NULL),
  ('gen.IP_RESTAPI',NULL, 'putIPWorkOrderPm (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.WORKORDER.MX',NULL,NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPWorkOrderNoncore (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.WORKORDER.MX',NULL,NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPWorkOrderQuote (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.WORKORDER.MX',NULL,NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPWorkOrderReactive (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.WORKORDER.MX',NULL,NULL),
  ('gen.IP_RESTAPI',NULL, 'postIPWorkOrderPm (Implementation).SetupRouting',1, 'queue:///IP.DOCUMENT_STORER.MX;queue:///IP.WORKORDER.MX',NULL,NULL);
  