---
# FMCDELIB.AddToErrorResponse

**Parameters:**
- `IN` `Root` `REFERENCE` null
- `IN` `Environment` `REFERENCE` null
- `IN` `userErrorCode` `CHAR` null
- `IN` `userErrorMsg` `CHAR` null

---
# FMCDELIB.AssertChildCharacteristics

**Parameters:**
- `IN` `Root` `REFERENCE` null
- `IN` `Environment` `REFERENCE` null
- `IN` `parent` `REFERENCE` null
- `IN` `fldnam` `CHAR` null
- `IN` `mustExist` `BOOLEAN` null
- `IN` `fldtyp` `CHAR` null
- `IN` `fldfmt` `CHAR` null
- `IN` `minLen` `INTEGER` null
- `IN` `maxLen` `INTEGER` null

---
# FMCDELIB.C\_ASSET\_SYNC\_ALL

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_ASSET\_SYNC\_UPD

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_SCHEDULE\_SYNC

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_CLICK\_INSTRUCT\_WORK

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_CLICK\_INSTRUCT\_WORK\_ACK

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_COMPLETE\_WORK\_RECEIVED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_FINAL\_INVOICE\_REQ

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_FIRM\_PRICE\_RECEIVED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_FIRM\_PRICE\_REJECTED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_FIRM\_PRICE\_REQUESTED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_MILESTONE\_PAYMENT\_REQ

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_MONTHLY\_UPDATE\_RECEIVED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_ON\_HOLD

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_OPTIONS\_RECEIVED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_OPTIONS\_REJECTED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_OPTIONS\_REQUESTED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_REINSTRUCT\_WORKS

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_REINSTRUCT\_WORKS\_ACK

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_RETIRE\_IMS\_WORK\_TASK

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_RETIRE\_IMS\_WORK\_TASK\_ACK

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_START\_WORK\_RECEIVED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_TASK\_RAISED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_TWC\_FIRM\_PRICE\_RECEIVED

**Returns:**
`CHAR` 

---
# FMCDELIB.C\_TASKS\_WORK\_VARIATION\_RECEIVED

**Returns:**
`CHAR` 

---
# FMCDELIB.CalcWorksDuration

**Parameters:**
- `IN` `imsDuration` `CHAR` null

**Returns:**
`INTEGER` 

---
# FMCDELIB.GetContractNumber

**Parameters:**
- `IN` `Root` `REFERENCE` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetCurrencyCode

**Parameters:**
- `IN` `currencyText` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetCurrencyText

**Parameters:**
- `IN` `currencyCode` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetPriorityCode

**Parameters:**
- `IN` `priorityText` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetPriorityText

**Parameters:**
- `IN` `priorityCode` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetSoNByOriginatorUniqueId

**Parameters:**
- `IN` `Environment` `REFERENCE` null
- `IN` `selectFields` `CHAR` null
- `IN` `originatorUniqueId` `CHAR` null

**Returns:**
`BOOLEAN` 

---
# FMCDELIB.GetStatementOfNeedTypeCode

**Parameters:**
- `IN` `statementOfNeedTypeText` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetStatementOfNeedTypeText

**Parameters:**
- `IN` `statementOfNeedTypeCode` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetTaskLifecycleStageCode

**Parameters:**
- `IN` `taskLifecycleStageText` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetTaskLifecycleStageText

**Parameters:**
- `IN` `taskLifecycleStageCode` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetTaxTypeCode

**Parameters:**
- `IN` `taxTypeText` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.GetTaxTypeText

**Parameters:**
- `IN` `taxTypeCode` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.HTTPHEADER\_DIOCONTRACTNUM

**Returns:**
`CHAR` 

---
# FMCDELIB.IP\_APPNAME

**Returns:**
`CHAR` 

---
# FMCDELIB.ISO8601ToDate10

**Parameters:**
- `IN` `iso8601` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.ISO8601ToDateTime20

**Parameters:**
- `IN` `iso8601` `CHAR` null

**Returns:**
`CHAR` 

---
# FMCDELIB.MAXIMO\_APPNAME

**Returns:**
`CHAR` 

---
# FMCDELIB.MXOSLCGet

**Parameters:**
- `IN` `Environment` `REFERENCE` null
- `IN` `url` `CHAR` null

**Returns:**
`BOOLEAN` 

---
# FMCDELIB.MXOSLCQuery

**Parameters:**
- `IN` `Environment` `REFERENCE` null
- `IN` `select_` `CHAR` null
- `IN` `where_` `CHAR` null
- `IN` `url` `CHAR` null

**Returns:**
`BOOLEAN` 

---
# FMCDELIB.MapDocLinksToExternalDocuments

**Parameters:**
- `IN` `doclinks` `REFERENCE` null
- `IN` `parent` `REFERENCE` null
- `IN` `Environment` `REFERENCE` null

---
# FMCDELIB.MapDocLinksToSwagger

**Parameters:**
- `IN` `doclinks` `REFERENCE` null
- `IN` `parent` `REFERENCE` null
- `IN` `Environment` `REFERENCE` null

---
# FMCDELIB.MapExternalDocumentsToDocLinks

**Parameters:**
- `IN` `externalDocuments` `REFERENCE` null
- `IN` `parent` `REFERENCE` null

---
# FMCDELIB.MapSwaggerToDocLinks

**Parameters:**
- `IN` `documents` `REFERENCE` null
- `IN` `parent` `REFERENCE` null

---
# FMCDELIB.OSLCUpdate

**Parameters:**
- `IN` `Environment` `REFERENCE` null
- `IN` `OutputRoot` `REFERENCE` null
- `IN` `url` `CHAR` null

**Returns:**
`BOOLEAN` 

---
# FMCDELIB.SetContractNumber

**Parameters:**
- `IN` `Root` `REFERENCE` null
- `IN` `contractnum` `CHAR` null

---
# FMCDELIB.TRIRIGA\_APPNAME

**Returns:**
`CHAR` 

---
# FMCDELIB.TROSLCGet

**Parameters:**
- `IN` `Environment` `REFERENCE` null
- `IN` `url` `CHAR` null

**Returns:**
`BOOLEAN` 

---
# FMCDELIB.TROSLCQuery

**Parameters:**
- `IN` `Environment` `REFERENCE` null
- `IN` `select_` `CHAR` null
- `IN` `where_` `CHAR` null
- `IN` `url` `CHAR` null

**Returns:**
`BOOLEAN` 

---
# FMCDELIB.ValidateField

**Parameters:**
- `IN` `Root` `REFERENCE` null
- `IN` `Environment` `REFERENCE` null
- `IN` `fldnam` `CHAR` null
- `IN` `mustExist` `BOOLEAN` null

---
# FMCDELIB.\_\_OSLCGet

**Parameters:**
- `IN` `Environment` `REFERENCE` null
- `IN` `url` `CHAR` null
- `IN` `sourceSystem` `CHAR` null
- `IN` `targetSystem` `CHAR` null

**Returns:**
`BOOLEAN` 

---
# FMCDELIB.\_\_OSLCQuery

**Parameters:**
- `IN` `Environment` `REFERENCE` null
- `IN` `select_` `CHAR` null
- `IN` `where_` `CHAR` null
- `IN` `url` `CHAR` null
- `IN` `sourceSystem` `CHAR` null
- `IN` `targetSystem` `CHAR` null

**Returns:**
`BOOLEAN` 

