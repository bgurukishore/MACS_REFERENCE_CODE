package sourcecode;

import org.apache.commons.lang3.StringUtils;

public class SCParm {
	private String inout = null;
	private String name = null;
	private String datatype = null;
	private String description = null;

	public SCParm(String inout, String name, String datatype) {
		super();
		this.inout = inout;
		this.name = name;
		this.datatype = datatype;
	}

	public String getInout() {
		return inout;
	}

	public String getName() {
		return name;
	}

	public String getDatatype() {
		return datatype;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Parameter: ");
		sb.append(inout);
		sb.append(" ");
		sb.append(name);
		sb.append(" ");
		sb.append(datatype);
		if (StringUtils.isNotBlank(description)) {
			sb.append(" - ");
			sb.append(description);
		}
		return sb.toString();
	}
	
}
