package sourcecode;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.apache.commons.lang3.StringUtils;

public class SCProc implements Comparable<SCProc> {
	protected String filename;
	protected int lineNo;
	protected String schema;
	protected String name;
	protected String returningType = StringUtils.EMPTY;
	protected String returningDesc = StringUtils.EMPTY;
	protected List<SCParm> parms = new ArrayList<SCParm>();
	private String description = StringUtils.EMPTY;
	private Set<String> see = new TreeSet<String>();

	public SCProc(String filename, int lineNo, String schema, String name) {
		super();
		this.filename = filename;
		this.lineNo = lineNo;
		this.schema = schema;
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public int getLineNo() {
		return lineNo;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReturningType() {
		return returningType;
	}

	public void setReturningType(String returningType) {
		this.returningType = returningType;
	}

	public String getReturningDesc() {
		return returningDesc;
	}

	public void setReturningDesc(String returningDesc) {
		this.returningDesc = returningDesc;
	}

	public void addParm(String inout, String name, String datatype) {
		parms.add(new SCParm(inout, name, datatype));
	}

	public SCParm getParm(String name) {
		SCParm parm = null;
		for (SCParm p : parms) {
			if (name.equalsIgnoreCase(p.getName())) {
				parm = p;
			}
		}
		return parm;
	}

	public void addSee(String see) {
		this.see.add(see);
	}

	public String[] getSee() {
		return this.see.toArray(new String[0]);
	}

	public String[] getParmNames() {
		List<String> names = new ArrayList<String>();
		for (SCParm p : parms) {
			names.add(p.getName());
		}
		return names.toArray(new String[0]);
	}

	public String getName() {
		StringBuilder sb = new StringBuilder();
		if (StringUtils.isNotBlank(schema)) {
			sb.append(schema + ".");
		}
		sb.append(name);
		return sb.toString();
	}

	@Override
	public int compareTo(SCProc o) {
		return this.getName().compareTo(o.getName());
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("PROC ");
		sb.append(getName());
		sb.append(" (");
		sb.append(Integer.toString(lineNo));
		sb.append(")");
		sb.append(System.lineSeparator());
		sb.append(getDescription());
		sb.append(System.lineSeparator());
		for (SCParm parm : parms) {
			sb.append(parm.toString());
			sb.append(System.lineSeparator());
		}
		return sb.toString();
	}
}
