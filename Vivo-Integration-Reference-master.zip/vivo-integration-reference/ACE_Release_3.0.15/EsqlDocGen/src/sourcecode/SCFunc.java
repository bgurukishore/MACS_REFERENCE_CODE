package sourcecode;

import org.apache.commons.lang3.StringUtils;

public class SCFunc extends SCProc {

	public SCFunc(String filename, int lineNo, String schema, String name) {
		super(filename, lineNo, schema, name);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("FUNC ");
		if (StringUtils.isNotBlank(schema)) {
			sb.append(schema + ".");
		}
		sb.append(name);
		sb.append(System.lineSeparator());
		sb.append(getDescription());
		sb.append(System.lineSeparator());
		for (SCParm parm : parms) {
			sb.append(parm.toString());
			sb.append(System.lineSeparator());
		}
		sb.append("RETURNS ");
		sb.append(getReturningType());
		sb.append(" - ");
		sb.append(getReturningDesc());
		return sb.toString();
	}
}
