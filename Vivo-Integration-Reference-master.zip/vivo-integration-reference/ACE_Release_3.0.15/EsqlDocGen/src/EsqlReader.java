import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;

import sourcecode.SCFunc;
import sourcecode.SCParm;
import sourcecode.SCProc;

public class EsqlReader {
	enum PARSE_STATE {
		VOID, MODULE, PROCEDURE, FUNCTION
	};

	private final Pattern BROKER_SCHEMA = Pattern.compile(
			"\\s*BROKER\\s+SCHEMA\\s+([\\w]*)", Pattern.CASE_INSENSITIVE);
	private final Pattern CREATE_PROCEDURE = Pattern.compile(
			"\\s*CREATE\\s+PROCEDURE\\s+([\\w]*)\\s*\\((.*)?\\)",
			Pattern.CASE_INSENSITIVE);
	private final Pattern CREATE_FUNCTION = Pattern
			.compile(
					"\\s*CREATE\\s+FUNCTION\\s+([\\w]*)\\s*\\((.*)?\\)\\s+RETURNS\\s+([\\w]*)",
					Pattern.CASE_INSENSITIVE);
	private final Pattern PARAMETER_ATTR = Pattern.compile(
			"\\s*@param\\s+([\\w]*)\\s+([\\w]*)\\s+[-]\\s+(.*)",
			Pattern.CASE_INSENSITIVE);
	private final Pattern RETURNS_ATTR = Pattern
			.compile("\\s*@returns\\s+([\\w]*)\\s+[-]\\s+(.*)",
					Pattern.CASE_INSENSITIVE);
	private final Pattern SEE_ATTR = Pattern.compile("\\s*@see\\s+([\\w\\.]*)",
			Pattern.CASE_INSENSITIVE);

	private String filename = null;
	private String schema = null;
	private int lineNo = 0;
	private Map<String, SCProc> procs;
	private final Map<Integer, String> locations = new TreeMap<Integer, String>();

	public EsqlReader(Map<String, SCProc> procs) {
		super();
		this.procs = procs;
	}

	public void read(Path path) throws FileNotFoundException, IOException {
		locations.clear();
		List<String> lines = FileUtils.readLines(path.toFile(),
				Charset.defaultCharset());
		String line = null;
		filename = path.toString();
		while (!lines.isEmpty()) {
			line = lines.remove(0);
			System.out.println(StringUtils.leftPad(Integer.toString(++lineNo),
					5) + " " + line);
			checkSchema(line, lines);
			checkProc(line, lines);
			checkFunc(line, lines);
		}
		readComments(path);
		addMissingComments(path);
	}

	private void addMissingComments(Path path) throws IOException {
		boolean updated = false;
		List<String> lines = FileUtils.readLines(path.toFile(),
				Charset.defaultCharset());
		Integer[] lineNos = locations.keySet().toArray(new Integer[0]);
		for (int i = lineNos.length - 1; i >= 0; i--) {
			SCProc proc = procs.get(locations.get(lineNos[i]));
			if (StringUtils.isBlank(proc.getDescription())) {
				updated = true;
				int insertAt = lineNos[i] - 1;
				lines.add(insertAt, StringUtils.repeat('*', 70) + " */");
				lines.add(insertAt, "*");
				if (proc instanceof SCFunc
						&& StringUtils.isNotBlank(proc.getReturningType())) {
					lines.add(insertAt, "* @returns "
							+ proc.getReturningType().toUpperCase()
							+ " - add description here");
					lines.add(insertAt, "*");
				}
				String[] parmNames = proc.getParmNames();
				for (int pi = parmNames.length - 1; pi >= 0; pi--) {
					lines.add(insertAt, "* @param " + parmNames[pi] + " "
							+ proc.getParm(parmNames[pi]).getDatatype()
							+ " - add description here");
				}
				lines.add(insertAt, "*");
				lines.add(insertAt, "* add description here");
				if (proc instanceof SCFunc) {
					lines.add(insertAt, "* @func " + proc.getName());
				} else {
					lines.add(insertAt, "* @proc " + proc.getName());
				}
				lines.add(insertAt, "*");
				lines.add(insertAt, "/* " + StringUtils.repeat('*', 70));
			}
		}
		for (String line : lines) {
			System.out.println(" > " + line);
		}
		if (updated) {
			File destFile = path.toFile();
			destFile = new File(destFile.getParentFile(),
					FilenameUtils.getBaseName(destFile.getName()) + ".esql_bak");
			FileUtils.copyFile(path.toFile(), destFile);
			FileUtils.writeLines(path.toFile(), lines);
		}
	}

	private void readComments(Path path) throws FileNotFoundException,
			IOException {
		SCProc proc = null;
		List<String> lines = FileUtils.readLines(path.toFile(),
				Charset.defaultCharset());
		String line = null;
		boolean iscomment = false;
		boolean skipblanklines = false;
		String procname = StringUtils.EMPTY;
		String procdesc = StringUtils.EMPTY;
		boolean readingdesc = false;
		filename = path.toString();
		while (!lines.isEmpty()) {
			line = lines.remove(0);
			lineNo++;
			if (line.trim().startsWith("/*") && !iscomment) {
				iscomment = true;
				readingdesc = false;
				procname = StringUtils.EMPTY;
				procdesc = StringUtils.EMPTY;
				skipblanklines = true;
				continue;
			}
			if (iscomment) {
				if (line.trim().startsWith("*")) {
					line = line.trim().substring(1).trim();
				}
				System.out.println(" >>> " + line);
				if (skipblanklines) {
					if (StringUtils.isBlank(line)) {
						continue;
					} else {
						skipblanklines = false;
					}
				}

				if (StringUtils.isNotBlank(procname)
						&& StringUtils.isBlank(procdesc)) {
					readingdesc = true;
				}
				if (line.startsWith("@proc") || line.startsWith("@func")) {
					procname = line.substring(5).trim();
					if (StringUtils.isNotBlank(schema)
							&& !procname.startsWith(schema + ".")) {
						procname = schema + "." + procname;
					}
				}
				if (line.startsWith("@param")) {
					Matcher m = PARAMETER_ATTR.matcher(line);
					if (m.find() && proc != null) {
						SCParm parm = proc.getParm(m.group(1));
						if (parm != null) {
							parm.setDescription(m.group(3));
						}
					}
				}
				if (line.startsWith("@see")) {
					Matcher m = SEE_ATTR.matcher(line);
					if (m.find() && proc != null) {
						proc.addSee(m.group(1));
					}
				}
				if (line.startsWith("@returns")) {
					Matcher m = RETURNS_ATTR.matcher(line);
					if (m.find() && proc != null) {
						proc.setReturningDesc(m.group(2));
					}
				}
				if (StringUtils.isNotBlank(procname)
						&& StringUtils.isNotBlank(procdesc)
						&& StringUtils.isBlank(line)) {
					readingdesc = false;
					proc = procs.get(procname);
					if (proc != null) {
						proc.setDescription(procdesc);
					}
				}
				if (readingdesc) {
					if (StringUtils.isNotBlank(procdesc)) {
						procdesc += " ";
					}
					procdesc += line.trim();
				}
				if (line.trim().endsWith("*/")) {
					iscomment = false;
				}
			}
		}
	}

	private void checkSchema(String line, List<String> lines) {
		Matcher m = BROKER_SCHEMA.matcher(line);
		if (!m.find()) {
			return;
		}
		schema = m.group(1);
	}

	private void checkProc(String line, List<String> lines) {
		Matcher m = CREATE_PROCEDURE.matcher(line);
		if (!m.find()) {
			return;
		}
		String name = m.group(1);
		if (!"CopyMessageHeaders".equalsIgnoreCase(name)
				&& !"CopyEntireMessage".equalsIgnoreCase(name)) {
			SCProc proc = new SCProc(filename, lineNo, schema, name);
			addParms(proc, m.group(2));
			procs.put(proc.getName(), proc);
			locations.put(lineNo, proc.getName());
		}
	}

	private void addParms(SCProc proc, String parmlist) {
		for (String parm : parmlist.trim().split(",")) {
			String[] p = parm.trim().split(" ");
			if (p.length >= 3) {
				String inout = p[0];
				String name = p[1];
				String datatype = p[2];
				proc.addParm(inout, name, datatype);
			}
		}
	}

	private void checkFunc(String line, List<String> lines) {
		Matcher m = CREATE_FUNCTION.matcher(line);
		if (!m.find()) {
			return;
		}
		String name = m.group(1);
		if (!"Main".equalsIgnoreCase(name)) {
			SCFunc proc = new SCFunc(filename, lineNo, schema, name);
			addParms(proc, m.group(2));
			proc.setReturningType(m.group(3));
			procs.put(proc.getName(), proc);
			locations.put(lineNo, proc.getName());
		}
	}
}
