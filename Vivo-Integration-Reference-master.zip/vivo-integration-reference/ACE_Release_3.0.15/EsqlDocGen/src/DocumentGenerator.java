import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;

import sourcecode.SCParm;
import sourcecode.SCProc;

public class DocumentGenerator {
	public static void main(String[] args) {
		try {
			// new DocumentGenerator(
			// "C:\\Users\\ma_p_sharpe\\IBM\\ACET11\\src\\FMCDE\\DIOLIB\\trunk")
			// .readEsql(Paths
			// .get("C:\\Users\\ma_p_sharpe\\IBM\\ACET11\\src\\FMCDE\\DIOLIB\\trunk",
			// "DIOLIB\\DIOLIB\\FileHelper.esql"));
			//new DocumentGenerator("../DIOLIB").generate();
			new DocumentGenerator("../FMCDELIB").generate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private String basedir = null;
	private TreeMap<String, SCProc> procs = new TreeMap<String, SCProc>();

	public DocumentGenerator(String basedir) {
		super();
		this.basedir = basedir;
	}

	public void generate() throws IOException {
		this.generate(Paths.get(basedir));
	}

	private void generate(Path path) throws IOException {
		if (!Files.isReadable(path)) {
			return;
		}
		String name = path.getFileName().toString();
		if (Files.isDirectory(path)) {
			if (name.startsWith(".")) {
				return;
			}
			try (DirectoryStream<Path> stream = Files.newDirectoryStream(path)) {
				for (Path entry : stream) {
					generate(entry);
				}
			}
		} else if (Files.isRegularFile(path)) {
			if (name.toLowerCase().endsWith(".esql")) {
				// System.out.println(path);
				readEsql(path);

			}
		}
	}

	private void readEsql(Path path) throws FileNotFoundException, IOException {
		new EsqlReader(procs).read(path);
		writeMarkdown();
	}

	private void writeMarkdown() throws IOException {
		try (FileWriter output = new FileWriter("funcs.md")) {
			for (SCProc proc : procs.values()) {
				output.write("---" + System.lineSeparator());
				output.write("# "
						+ StringUtils.replace(proc.getName(), "_", "\\_")
						+ System.lineSeparator());
				output.write(proc.getDescription() + System.lineSeparator());
				String[] parmNames = proc.getParmNames();
				if (parmNames.length > 0) {
					output.write("**Parameters:**" + System.lineSeparator());
					for (String parmName : parmNames) {
						SCParm parm = proc.getParm(parmName);
						output.write("- `" + parm.getInout() + "` `"
								+ parm.getName() + "` `" + parm.getDatatype()
								+ "` " + parm.getDescription()
								+ System.lineSeparator());
					}
					output.write(System.lineSeparator());
				}
				if (StringUtils.isNotBlank(proc.getReturningType())) {
					output.write("**Returns:**" + System.lineSeparator());
					output.write("`" + proc.getReturningType() + "` "
							+ proc.getReturningDesc() + System.lineSeparator());
					output.write(System.lineSeparator());
				}
				if (proc.getSee().length > 0) {
					output.write("**See:** ");
					StringBuilder sb = new StringBuilder();
					for (String see : proc.getSee()) {
						if (sb.length() > 0) {
							sb.append(", ");
						}
						sb.append(see);
					}
					output.write(sb.toString());
					output.write(System.lineSeparator());
					output.write(System.lineSeparator());
				}
			}
		}
	}
}
