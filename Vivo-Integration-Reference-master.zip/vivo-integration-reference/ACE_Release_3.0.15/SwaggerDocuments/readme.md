# 
This is a central store for YAML files.
The master files will always reside in the applicable application, this is intended as a convienience location only and may be removed at some future date.