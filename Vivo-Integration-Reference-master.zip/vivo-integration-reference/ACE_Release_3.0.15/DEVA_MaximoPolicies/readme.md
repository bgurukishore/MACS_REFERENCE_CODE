oslc.qm.baseurl is the Quote Management (SoN & Task) base URL
oslc.cm.baseurl is the Cost Management (Task after "Instruct Work") base URL
 