package DIOLIB;

import java.nio.charset.Charset;

import DIOLIB.MQWriter.MQWriterCategory;

public class Logger {
	private static final String QUEUE_NAME = "TO_LOG";

	private Charset UTF8 = Charset.forName("UTF-8");

	private String loggerName = null;
	private String brokerName = null;
	private String executionGroupName = null;
	private String messageFlowName = null;
	private String nodeName = null;
	private String queueManagerName = null;

	public Logger(String loggerName) {
		super();
		this.loggerName = loggerName;
	}

	public String getLoggerName() {
		return loggerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	public void setExecutionGroupName(String executionGroupName) {
		this.executionGroupName = executionGroupName;
	}

	public void setMessageFlowName(String messageFlowName) {
		this.messageFlowName = messageFlowName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public void setQueueManagerName(String queueManagerName) {
		this.queueManagerName = queueManagerName;
	}

	public void error(CharSequence message) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME,
				MQWriterCategory.LOG_ERROR, message.toString().getBytes(UTF8));
	}

	public void error(Throwable t) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME,
				MQWriterCategory.LOG_ERROR,
				t.getLocalizedMessage().getBytes(UTF8));
	}

	public void error(CharSequence message, Throwable t) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME,
				MQWriterCategory.LOG_ERROR, message.toString().getBytes(UTF8));
	}

	public void fatal(CharSequence message) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME,
				MQWriterCategory.LOG_FATAL, message.toString().getBytes(UTF8));
	}

	public void fatal(Throwable t) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME,
				MQWriterCategory.LOG_FATAL,
				t.getLocalizedMessage().getBytes(UTF8));
	}

	public void fatal(CharSequence message, Throwable t) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME,
				MQWriterCategory.LOG_FATAL, message.toString().getBytes(UTF8));
	}

	public void warn(CharSequence message) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME,
				MQWriterCategory.LOG_WARN, message.toString().getBytes(UTF8));
	}

	public void debug(CharSequence message) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME,
				MQWriterCategory.LOG_DEBUG, message.toString().getBytes(UTF8));
	}

	public void info(CharSequence message) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME,
				MQWriterCategory.LOG_INFO, message.toString().getBytes(UTF8));
	}

	public Boolean isDebugEnabled() {
		return Boolean.TRUE;
	}

}
