package DIOLIB;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.commons.lang3.StringUtils;

public class HostHelper {
	private static final Logger logger = LogManager.getLogger(HostHelper.class);

	// public static void main(String[] args) {
	// System.out.println(getHostname());
	// try {
	// System.out.println(InetAddress.getLocalHost().getCanonicalHostName());
	// } catch (UnknownHostException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }

	public static String getHostname() {
		try {
			return InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			logger.error(e);
		}
		return StringUtils.EMPTY;
	}

	public static String getCanonicalHostName() {
		try {
			return InetAddress.getLocalHost().getCanonicalHostName();
		} catch (UnknownHostException e) {
			logger.error(e);
		}
		return StringUtils.EMPTY;
	}
}
