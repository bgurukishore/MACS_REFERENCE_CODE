package DIOLIB;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

public class FileHelper {

//	public static void main(String[] args) {
//		String filename = "file://hostname/doclinks/Attachments/DIOCB6%207018/TASK/1199298/20210317_110115389.txt";
//		System.out.println(URI.create(filename).getPath());
//		System.out.println(Paths.get(URI.create(filename)).getParent());
//		System.out.println(getFileSize(filename));
//	}

	// private static final Charset utf8 = Charset.forName("UTF-8");

	public static Boolean writeToFile(String filename, byte[] bytes) {
		boolean writeToFile = false;
		File file = toFile(filename);
		try {
			FileUtils.writeByteArrayToFile(file, bytes);
			writeToFile = true;
		} catch (IOException e) {
			e.printStackTrace(System.err);
		}
		return writeToFile;
	}

	public static Boolean readFromFile(String filename, byte[][] content) {
		boolean readFromFile = false;
		File file = toFile(filename);
		try (FileInputStream reader = new FileInputStream(file)) {
			byte[] cbuf = new byte[(int) file.length()];
			reader.read(cbuf);
			content[0] = cbuf;
			readFromFile = true;
		} catch (IOException e) {
			e.printStackTrace(System.err);
			content[0] = new byte[] {}; // empty content
		}
		return readFromFile;
	}

	public static Boolean deleteFile(String filename) {
		return FileUtils.deleteQuietly(new File(filename));
	}

	public static Boolean fileExists(String filename) {
		return new File(filename).exists();
	}

	public static Boolean isDirectory(String filename) {
		return new File(filename).isDirectory();
	}

	public static Boolean appendToFile(String filename, byte[] bytes) {
		boolean appendToFile = false;
		File file = new File(filename);
		try {
			FileUtils.writeByteArrayToFile(file, bytes, true);
			appendToFile = true;
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
		return appendToFile;
	}

	public static Boolean moveFile(String srcFilename, String destFilename) {
		boolean moveFile = false;
		try {
			FileUtils.moveFile(new File(srcFilename), new File(destFilename));
			moveFile = true;
		} catch (IOException e) {
			e.printStackTrace(System.err);
		}
		return moveFile;
	}

	public static Long getFileSize(String filename) {
		File file = toFile(filename);
		try {
			return FileUtils.sizeOf(file);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
		return -1L;
	}

	public static Boolean mkdirs(String path) {
		File dir = new File(path);
		if (dir.isDirectory()) {
			return true;
		}
		if (!dir.exists()) {
			return dir.mkdirs();
		}
		return false;
	}

	public static String getBaseName(String filename) {
		return FilenameUtils.getBaseName(filename);
	}

	public static String getExtension(String filename) {
		return FilenameUtils.getExtension(filename);
	}

	public static String getFilenameAsURI(String filename) {
		return new File(filename).toURI().toString();
	}
	public static String getFilePathAsURI(String filename) {
		return Paths.get(filename).toUri().toString();
	}
	private static File toFile(String filename) {
		File file = null;
		if (filename.startsWith("file:")) {
			filename = filename.substring(5);
		}
		file = new File(filename.replace("%20", " "));
		System.out.println(file);
		return file;
	}
}
