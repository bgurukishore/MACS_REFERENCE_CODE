package DIOLIB;

import java.io.ByteArrayInputStream;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Element;

public class XmlHelper {
	private static final Logger logger = LogManager.getLogger(XmlHelper.class);

	public static String xmlPrettyPrint(String xmlStr, boolean indent) {
		if (StringUtils.isNotBlank(xmlStr)) {
			Element node;
			try {
				node = DocumentBuilderFactory.newInstance()
						.newDocumentBuilder()
						.parse(new ByteArrayInputStream(xmlStr.getBytes()))
						.getDocumentElement();
				Transformer serializer = TransformerFactory.newInstance()
						.newTransformer();
				if (indent) {
					serializer.setOutputProperty(OutputKeys.INDENT, "yes");
					serializer.setOutputProperty(
							"{http://xml.apache.org/xslt}indent-amount", "2");
				} else {
					serializer.setOutputProperty(OutputKeys.INDENT, "no");
				}
				serializer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION,
						"yes");
				// initialize StreamResult with File object to save to file
				StreamResult result = new StreamResult(new StringWriter());
				DOMSource source = new DOMSource(node);
				serializer.transform(source, result);
				String s = result.getWriter().toString();
				return s;
			} catch (Exception e) {
				logger.error(e);
			}
		}
		return null;
	}

	public static String xmlPrettyPrint(String xmlStr) {
		return xmlPrettyPrint(xmlStr, true);
	}

	public static String xmlPrint(String xmlStr) {
		return xmlPrettyPrint(xmlStr, false);
	}

}
