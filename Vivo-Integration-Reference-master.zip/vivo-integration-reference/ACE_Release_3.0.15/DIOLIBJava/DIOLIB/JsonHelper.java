package DIOLIB;

import org.apache.commons.lang3.StringUtils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

public class JsonHelper {
	private static final Logger logger = LogManager.getLogger(JsonHelper.class);

	public static String jsonPrettyPrint(String jsonStr) {
		if (StringUtils.isNotBlank(jsonStr)) {
			return __jsonPrint__(jsonStr, new GsonBuilder()
					.disableHtmlEscaping().setPrettyPrinting().create());
		}
		return null;
	}

	public static String jsonPrint(String jsonStr) {
		if (StringUtils.isNotBlank(jsonStr)) {
			return __jsonPrint__(jsonStr, new GsonBuilder()
					.disableHtmlEscaping().create());
		}
		return null;
	}

	private static String __jsonPrint__(String jsonStr, Gson gson) {
		try {
			JsonElement parseThis = new JsonParser().parse(jsonStr);
			if (parseThis.isJsonObject()) {
				return gson.toJson(parseThis.getAsJsonObject());
			} else if (parseThis.isJsonArray()) {
				return gson.toJson(parseThis.getAsJsonArray());
			} else if (parseThis.isJsonPrimitive()) {
				return gson.toJson(parseThis.getAsJsonPrimitive());
			} else if (parseThis.isJsonNull()) {
				return gson.toJson(parseThis.getAsJsonNull());
			}
		} catch (JsonSyntaxException e) {
			logger.error(e);
		}
		return null;
	}
}
