package DIOLIB;

import org.apache.commons.lang3.StringUtils;

public class Log4jWrapper {

	public static void log(String loggerName, String level, String message) {
		Logger log = LogManager.getLogger(loggerName);
		if (StringUtils.isBlank(level)) {
			level = "debug";
		}
		switch (level.charAt(0)) {
		case 'e':
		case 'E':
			log.error(message);
			break;
		case 'f':
		case 'F':
			log.fatal(message);
			break;
		case 'i':
		case 'I':
			log.info(message);
			break;
		case 'w':
		case 'W':
			log.warn(message);
			break;
		default:
			log.debug(message);
		}
	}

	public static void debug(String brokerName, String executionGroupName,
			String messageFlowName, String nodeName, String queueManagerName,
			String message) {
		if (StringUtils.isBlank(message)) {
			return;
		}
		Logger log = LogManager.getLogger(brokerName + "." + executionGroupName
				+ "." + messageFlowName + "." + nodeName);
		log.setBrokerName(brokerName);
		log.setExecutionGroupName(executionGroupName);
		log.setMessageFlowName(messageFlowName);
		log.setNodeName(nodeName);
		log.setQueueManagerName(queueManagerName);
		log.debug(message);
	}

	public static void info(String brokerName, String executionGroupName,
			String messageFlowName, String nodeName, String queueManagerName,
			String message) {
		if (StringUtils.isBlank(message)) {
			return;
		}
		Logger log = LogManager.getLogger(brokerName + "." + executionGroupName
				+ "." + messageFlowName + "." + nodeName);
		log.setBrokerName(brokerName);
		log.setExecutionGroupName(executionGroupName);
		log.setMessageFlowName(messageFlowName);
		log.setNodeName(nodeName);
		log.setQueueManagerName(queueManagerName);
		log.info(message);
	}

	public static void warn(String brokerName, String executionGroupName,
			String messageFlowName, String nodeName, String queueManagerName,
			String message) {
		if (StringUtils.isBlank(message)) {
			return;
		}
		Logger log = LogManager.getLogger(brokerName + "." + executionGroupName
				+ "." + messageFlowName + "." + nodeName);
		log.setBrokerName(brokerName);
		log.setExecutionGroupName(executionGroupName);
		log.setMessageFlowName(messageFlowName);
		log.setNodeName(nodeName);
		log.setQueueManagerName(queueManagerName);
		log.warn(message);
	}

	public static void error(String brokerName, String executionGroupName,
			String messageFlowName, String nodeName, String queueManagerName,
			String message) {
		if (StringUtils.isBlank(message)) {
			return;
		}
		Logger log = LogManager.getLogger(brokerName + "." + executionGroupName
				+ "." + messageFlowName + "." + nodeName);
		log.setBrokerName(brokerName);
		log.setExecutionGroupName(executionGroupName);
		log.setMessageFlowName(messageFlowName);
		log.setNodeName(nodeName);
		log.setQueueManagerName(queueManagerName);
		log.error(message);
	}

	public static void fatal(String brokerName, String executionGroupName,
			String messageFlowName, String nodeName, String queueManagerName,
			String message) {
		if (StringUtils.isBlank(message)) {
			return;
		}
		Logger log = LogManager.getLogger(brokerName + "." + executionGroupName
				+ "." + messageFlowName + "." + nodeName);
		log.setBrokerName(brokerName);
		log.setExecutionGroupName(executionGroupName);
		log.setMessageFlowName(messageFlowName);
		log.setNodeName(nodeName);
		log.setQueueManagerName(queueManagerName);
		log.fatal(message);
	}

	public static Boolean isDebugEnabled(String brokerName,
			String executionGroupName, String messageFlowName, String nodeName,
			String queueManagerName) {
		Logger log = LogManager.getLogger(brokerName + "." + executionGroupName
				+ "." + messageFlowName + "." + nodeName);
		log.setBrokerName(brokerName);
		log.setExecutionGroupName(executionGroupName);
		log.setMessageFlowName(messageFlowName);
		log.setNodeName(nodeName);
		log.setQueueManagerName(queueManagerName);
		return Boolean.valueOf(log.isDebugEnabled());
	}
}
