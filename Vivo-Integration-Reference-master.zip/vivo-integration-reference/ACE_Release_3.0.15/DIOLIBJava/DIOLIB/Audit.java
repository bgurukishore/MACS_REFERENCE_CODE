package DIOLIB;

import DIOLIB.MQWriter.MQWriterCategory;

public class Audit {

	private static final String QUEUE_NAME = "TO_AUDIT";

	public static void auditEvent(String brokerName, String executionGroupName,
			String messageFlowName, String nodeName, String queueManagerName,
			String auditEventGroupId, byte[] auditEventData) {
		MQWriter.write(brokerName, executionGroupName, messageFlowName,
				nodeName, queueManagerName, QUEUE_NAME, MQWriterCategory.AUDIT,
				auditEventData);
	}
}
