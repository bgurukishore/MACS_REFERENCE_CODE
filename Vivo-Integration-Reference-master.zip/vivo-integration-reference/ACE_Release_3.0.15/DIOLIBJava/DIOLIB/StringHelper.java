package DIOLIB;

import java.nio.charset.Charset;
import java.util.HashSet;
import java.util.Set;

public class StringHelper {
	public static final String EMPTY = "";

	public static String lineSep() {
		return System.getProperty("line.separator");
	}

	public static boolean hasText(String str) {
		return str != null && !str.trim().equals(EMPTY);
	}

	public static String delimitedListAsDelimitedSet(String listStr,
			String delim) {
		final Set<String> set = new HashSet<String>();
		for (String s : listStr.split(delim)) {
			set.add(s);
		}
		return set.toString();
	}

	public static String toString(byte[] bytes) {
		if (bytes == null) {
			return null;
		}
		return new String(bytes, Charset.defaultCharset());
	}

}
