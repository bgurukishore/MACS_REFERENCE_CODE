package DIOLIB;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashHelper {
	private static final Logger logger = LogManager.getLogger(HashHelper.class);

	// public static void main(String[] args) {
	// System.out.println(HashHelper.sha512(new byte[] { 1, 34, 44 }));
	// }

	public static byte[] sha512(byte[] bytes) {
		return hash(bytes, "sha512");
	}

	private static byte[] hash(byte[] bytes, String algorithm) {
		try {
			MessageDigest messageDigest = MessageDigest.getInstance(algorithm);
			return messageDigest.digest(bytes);
		} catch (NoSuchAlgorithmException e) {
			logger.fatal(e);
		}
		return null;
	}

}
