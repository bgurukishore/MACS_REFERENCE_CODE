package DIOLIB;

public class LogManager {

	public static Logger getLogger(Class<?> _class) {
		return LogManager.getLogger(_class.getCanonicalName());
	}

	public static Logger getLogger(String loggerName) {
		return new Logger(loggerName);
	}

}
