package DIOLIB;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class URLHelper {
	private static final Logger logger = LogManager.getLogger(URLHelper.class);

	public static String encodeValue(String value) {
		try {
			return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}

	public static String decodeValue(String value) {
		try {
			return URLDecoder.decode(value, StandardCharsets.UTF_8.toString());
		} catch (Exception e) {
			logger.error(e);
		}
		return null;
	}

}
