package DIOLIB;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

import org.apache.commons.pool2.BaseKeyedPooledObjectFactory;
import org.apache.commons.pool2.KeyedObjectPool;
import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.impl.DefaultPooledObject;
import org.apache.commons.pool2.impl.GenericKeyedObjectPool;
import org.apache.commons.pool2.impl.GenericKeyedObjectPoolConfig;

import com.ibm.mq.MQException;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.CMQC;
import com.ibm.mq.constants.MQConstants;
import com.ibm.mq.headers.MQRFH2;

public class MQWriter {
	enum MQWriterCategory {
		AUDIT, LOG_DEBUG, LOG_INFO, LOG_WARN, LOG_ERROR, LOG_FATAL
	}

	private static final KeyedObjectPool<String, MQQueueManager> queueManagers;
	private static final MQPutMessageOptions mqPutMessageOptions = new MQPutMessageOptions();

	static {
		mqPutMessageOptions.options = CMQC.MQPMO_NO_SYNCPOINT
				| CMQC.MQPMO_FAIL_IF_QUIESCING | CMQC.MQPMO_NEW_MSG_ID;
		GenericKeyedObjectPoolConfig<MQQueueManager> config = new GenericKeyedObjectPoolConfig<MQQueueManager>();
		config.setTestOnBorrow(true);
		config.setTestOnCreate(true);
		config.setTestOnReturn(false);
		config.setTimeBetweenEvictionRunsMillis(60000L);
		config.setMinEvictableIdleTimeMillis(60000L);
		queueManagers = new GenericKeyedObjectPool<String, MQQueueManager>(
				new BaseKeyedPooledObjectFactory<String, MQQueueManager>() {

					@Override
					public boolean validateObject(String key,
							PooledObject<MQQueueManager> p) {
						boolean validateObject = p.getObject().isConnected();
//						System.out.println("validateObject(\"" + key + "\","
//								+ p + ") = " + validateObject);
						return validateObject;
					}

					@Override
					public MQQueueManager create(String queueManagerName)
							throws Exception {
						MQQueueManager queueManager = new MQQueueManager(
								queueManagerName);
//						System.out.println("create(\"" + queueManagerName + "\") = " + queueManager);
						return queueManager;
					}

					@Override
					public PooledObject<MQQueueManager> wrap(
							MQQueueManager queueManager) {
						return new DefaultPooledObject<MQQueueManager>(
								queueManager);
					}

					@Override
					public void destroyObject(String key,
							PooledObject<MQQueueManager> p) throws Exception {
						p.getObject().disconnect();
//						System.out.println("destroyObject(\"" + key + "\"," + p
//								+ ") => SUCCESS");
					}

				}, config);
	}

	public static void write(String brokerName, String executionGroupName,
			String messageFlowName, String nodeName, String queueManagerName,
			String queueName, MQWriterCategory category, byte[] rawMessage) {
		MQQueueManager queueManager = null;
		MQQueue queue = null;
		try {
			queueManager = queueManagers.borrowObject(queueManagerName);
//			System.out.println("queueManager = " + queueManager);
			try {
				queue = queueManager.accessQueue(queueName,
						CMQC.MQOO_FAIL_IF_QUIESCING | CMQC.MQOO_INPUT_AS_Q_DEF
								| CMQC.MQOO_OUTPUT | CMQC.MQOO_INQUIRE);
				MQMessage message = new MQMessage();
				message.format = MQConstants.MQFMT_RF_HEADER_2;
				final MQRFH2 mqrfh2 = new MQRFH2();
				mqrfh2.setFormat(MQConstants.MQFMT_STRING);
				mqrfh2.setFieldValue(MQConstants.MQRFH2_USER_FOLDER,
						"BrokerName", brokerName);
				mqrfh2.setFieldValue(MQConstants.MQRFH2_USER_FOLDER,
						"ExecutionGroupName", executionGroupName);
				mqrfh2.setFieldValue(MQConstants.MQRFH2_USER_FOLDER,
						"MessageFlowName", messageFlowName);
				mqrfh2.setFieldValue(MQConstants.MQRFH2_USER_FOLDER,
						"NodeName", nodeName);
				mqrfh2.setFieldValue(MQConstants.MQRFH2_USER_FOLDER,
						"QueueManagerName", queueManagerName);
				mqrfh2.setFieldValue(MQConstants.MQRFH2_USER_FOLDER,
						"Category", category.toString());
				Calendar calendar = Calendar.getInstance();
				calendar.setTimeZone(TimeZone.getTimeZone("GMT"));
				mqrfh2.setFieldValue(MQConstants.MQRFH2_USER_FOLDER, "GMTTime",
						new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS")
								.format(calendar.getTime()));
				mqrfh2.setCodedCharSetId(1208);
				mqrfh2.setEncoding(546);
				try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
					try (DataOutputStream dos = new DataOutputStream(baos)) {
						mqrfh2.write(dos);
						dos.write(rawMessage);
					}
					message.write(baos.toByteArray());
				}
				queue.put(message, mqPutMessageOptions);
				commit(queueManager);
			} catch (Exception e) {
				e.printStackTrace(System.err);
			}
		} catch (Exception e) {
			e.printStackTrace(System.err);
		} finally {
			closeQuietly(queue);
			if (queueManager != null) {
				try {
					queueManagers.returnObject(queueManagerName, queueManager);
				} catch (Exception e) {
					if (queueManager != null) {
						try {
							queueManagers.invalidateObject(queueManagerName,
									queueManager);
						} catch (Exception e1) {
							e1.printStackTrace(System.err);
						}
					}
				}
			}
		}

	}

	private static void closeQuietly(MQQueue queue) {
		if (queue == null)
			return;
		try {
			queue.close();
		} catch (MQException e) {
			e.printStackTrace(System.err);
		}
	}

	private static void closeQuietly(MQQueueManager queueManager) {
		if (queueManager == null)
			return;
		try {
			queueManager.disconnect();
		} catch (MQException e) {
			e.printStackTrace(System.err);
		}
	}

	private static void commit(MQQueueManager queueManager) {
		if (queueManager == null)
			return;
		try {
			queueManager.commit();
		} catch (MQException e) {
			e.printStackTrace(System.err);
		}
	}

}
