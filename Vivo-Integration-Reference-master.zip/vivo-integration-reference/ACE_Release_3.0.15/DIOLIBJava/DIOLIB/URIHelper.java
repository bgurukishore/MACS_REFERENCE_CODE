package DIOLIB;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.net.URLEncoder;

import org.apache.commons.lang3.StringUtils;

import com.ibm.broker.plugin.MbElement;

public class URIHelper {
	private static final Logger logger = LogManager.getLogger(URIHelper.class);

	public static Boolean parse(String uriStr, String[] scheme,
			String[] username, String[] password, String[] host, Long[] port,
			String[] path, String[] query, String[] fragment,
			String[] errorMessage) {
		boolean result = false;
		URI uri;
		try {
			uri = URI.create(uriStr);
			scheme[0] = uri.getScheme();
			String userInfo = uri.getUserInfo();
			if (userInfo != null && !"".equals(userInfo)) {
				String[] arr = userInfo.split(":");
				switch (arr.length) {
				case 2: {
					password[0] = arr[1];
					// don't break, fall through to get the username
				}
				case 1: {
					username[0] = arr[0];
					break;
				}
				}
			}
			host[0] = uri.getHost();
			port[0] = (long) uri.getPort();
			path[0] = uri.getPath();
			query[0] = uri.getQuery();
			fragment[0] = uri.getFragment();
			result = true;
		} catch (NullPointerException | IllegalArgumentException e) {
			logger.error(e);
			scheme[0] = "error";
			errorMessage[0] = e.getLocalizedMessage();
		}
		return result;
	}

	public static String format(String scheme, String username,
			String password, String host, Long port, String path, String query,
			String fragment/* , String[] errorMessage */) {
		String userInfo = null;
		if (StringHelper.hasText(username)) {
			userInfo += username;
			if (StringHelper.hasText(password)) {
				userInfo += ":" + username;
			}
		}
		String uriStr = null;
		int _port = -1;
		if (port != null) {
			_port = port.intValue();
		}
		if (StringUtils.isBlank(query)) {
			query = null;
		}
		if (StringUtils.isBlank(fragment)) {
			fragment = null;
		}
		if (!StringUtils.isBlank(scheme) && !StringUtils.isBlank(path)
				&& !StringUtils.startsWith(path, "/")) {
			// cannot have a relative path with a scheme
			path = "/" + path;
		}
		try {
			URI uri = new URI(scheme, userInfo, host, _port, path, query,
					fragment);
			uriStr = uri.toString();
		} catch (URISyntaxException e) {
			/* errorMessage[0] = e.getLocalizedMessage(); */
			logger.error(e);
		}
		return uriStr;
	}

	public static void splitURIQuery(String uriStr, MbElement parentElm,
			String[] errorMessage) {
		if (StringUtils.isBlank(uriStr)) {
			errorMessage[0] = "Missing 'uriStr' parameter.";
			return;
		}
		try {
			URI uri = URI.create(uriStr);
			MbElement queryParameter = null;
			int idx = 0;
			String query = uri.getQuery();
			if (StringUtils.isNotBlank(query)) {
				String[] pairs = query.split("&");
				for (String pair : pairs) {
					idx = pair.indexOf("=");
					queryParameter = parentElm.createElementAsLastChild(
							MbElement.TYPE_NAME, "parm", null);
					queryParameter.createElementAsLastChild(
							MbElement.TYPE_NAME_VALUE,
							URLDecoder.decode(pair.substring(0, idx), "UTF-8")
									.trim(),
							URLDecoder.decode(pair.substring(idx + 1), "UTF-8")
									.trim());
				}
			}
		} catch (Exception e) {
			errorMessage[0] = e.getLocalizedMessage();
			logger.error(e);
		}
		return;
	}

	public static String URLDecode(String url) {
		if (StringUtils.isBlank(url)) {
			return null;
		}
		String decodedUrl = null;
		try {
			decodedUrl = URLDecoder.decode(url, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.error(e);
			decodedUrl = null;
		}
		return decodedUrl;
	}

	public static String URLEncode(String url) {
		if (StringUtils.isBlank(url)) {
			return null;
		}
		String encodedUrl = null;
		try {
			encodedUrl = URLEncoder.encode(url, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			logger.error(e);
			encodedUrl = null;
		}
		return encodedUrl;
	}

}
