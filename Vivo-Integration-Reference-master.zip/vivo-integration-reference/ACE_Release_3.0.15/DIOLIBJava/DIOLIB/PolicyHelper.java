package DIOLIB;

import org.apache.commons.lang3.StringUtils;

import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbPolicy;
import com.ibm.broker.plugin.MbProperty;

public class PolicyHelper {
	private static final Logger logger = LogManager
			.getLogger(PolicyHelper.class);
	private static final String POLICY_ENVIRONMENT_PREFIX;
	static {
		String envid = StringUtils.trim(System.getProperty(
				"policy.environment.prefix", ""));
		if (StringUtils.isBlank(envid)) {
			POLICY_ENVIRONMENT_PREFIX = StringUtils.EMPTY;
		} else {
			POLICY_ENVIRONMENT_PREFIX = (envid.endsWith("_") ? envid : envid
					+ "_");
		}
	}

	public static String getPolicyEnvironmentPrefix() {
		return POLICY_ENVIRONMENT_PREFIX;
	}

	public static String getPolicyPropertyValue(String policyProjectName,
			String policyName, String propertyName, String[] errorCode,
			String[] errorText) {
		String propertyValue = null;
		try {
			policyProjectName = POLICY_ENVIRONMENT_PREFIX + policyProjectName;
			MbPolicy policy = MbPolicy.getPolicy("UserDefined", "{"
					+ policyProjectName + "}:" + policyName);
			if (policy != null) {
				MbProperty property = policy.getProperty(propertyName);
				if (property == null) {
					errorCode[0] = "ERR:100026";
					errorText[0] = "Could not find property %1 in policy %2."
							.replace("%1", propertyName)
							.replace("%2",
									"{" + policyProjectName + "}:" + policyName);
				} else {
					propertyValue = property.valueAsString();
				}
			} else {
				errorCode[0] = "ERR:100024";
				errorText[0] = "Could not find policy: %1, in project: %2."
						.replace("%1", policyName).replace("%2",
								policyProjectName);
			}
		} catch (MbException e) {
			errorCode[0] = "ERR:100025";
			errorText[0] = "MbException caught in Java: %1".replace("%1",
					e.getLocalizedMessage());
		}
		return propertyValue;
	}
}
